#!/usr/bin/env python3
"""Generate metadata.json sesi-07 dari daftar klip yang sudah ter-upload.
State: out/uploaded.json = [{id, file, durasi, part, topik, ukuran}]
Pemakaian: python3 scripts/update-metadata.py"""
import json, os, subprocess

SESI = "sesi-07-nessie-judge-konspirasi-bencana"
GEM = {
    "judul": "NESSIE JUDGE GA PAKAI SENSOR NIH KALAU NGOMONG\u203c\ufe0fBENCANA BISA DIMANIPULASI?? - Underground",
    "channel": "Deddy Corbuzier",
    "url": "youtu.be/16ruF24xR1s",
    "durasi_total": "52:59",
}

# topik per klip (deskripsi kaya, gaya sesi-06)
TOPIK = {
    "clip-01-gempa-krakatau-buatan": "Pembukaan: klaim viral gempa tektonik = 'teknologi & elektronik' — gempa Krakatau dituduh buatan; Deddy membedah asal kata 'tektonik' dari Yunani; teori gelombang suara Tesla yang konon bisa meruntuhkan bangunan; pertanyaan pembuka: apakah Indonesia sedang dihantam senjata dari luar negeri?",
    "clip-02-haarp-senjata-gempa": "HAARP (High-frequency Active Auroral Research Program) dibedah: riset ionosfer di Alaska atau senjata rahasia? Sejarah klaim: Hugo Chavez 2010 sampai gempa Turki 2023 yang dikaitkan HAARP padahal 'lightning earthquake' punya penjelasan ilmiah; manipulasi cuaca vs gempa dibedah garis besarnya (troposfer vs ionosfer), plus dramatisasi lokasi terpencil seperti gunung Salak",
    "clip-03-operation-popeye-senjata-cuaca": "Jawaban atas 'ada dong senjata tersebut': Operation Popeye — eksperimen senjata cuaca Amerika di Perang Vietnam bikin hujan di jalur musuh; Project Seal bersama Selandia Baru era Perang Dunia II yang mengembangkan gelombang tsunami; teknologi cuaca memang ada, tapi sampai tahap senjata penghancur atau belum?",
    "clip-04-wifi-militer-sonik-mkultra": "Wi-Fi dulunya teknologi tentara yang disembunyikan — bukti teknologi bisa dipendekkan bertahun-tahun sebelum dipublikasikan; kasus tentara AS di Venezuela yang sakit kepala sampai hampir muntah karena senjata sonik; lalu proyek kontrol pikiran CIA: MKUltra & 'DCUltra' — manipulasi cara berpikir massal",
    "clip-05-tsunami-aceh-diego-garcia": "Konten Nessie soal tsunami Aceh yang dianggap bencana buatan: pangkalan AS Diego Garcia yang jaraknya ribuan km tapi kapal asing cepat tiba di pantai kita; isu ledakan bawah laut ala Project Seal; ditutup beda konsep HAARP vs Blue Beam, dan bisik-bisik 'NASA dan PBB menciptakan agama global'",
    "clip-06-bluebeam-agama-jadi-senjata": "Project Blue Beam versi Serge Monast: agama dipercaya jadi senjata terkuat di bumi — dipakai elite global untuk kontrol populasi lewat 'mesej' masa depan; analogi 10 Commandments dan semak terbakar; kok konsepnya mirip kemunculan dajal versi modern — mengaburkan keyakinan dengan tampilan teknologi",
    "clip-07-hologram-mesiah-kepanikan-alien": "Kelanjutan Blue Beam: mesiah hologram 3D — referensi Spider-Man Far From Home (drone + hologram monster); AI yang bikin konten makin membingungkan sampai 'cewek seksi AI' punya subscriber; skenario kepanikan global: musuh bersama fiktif untuk menyatukan dunia, persis arahan Ronald Reagan 1987 soal ancaman alien",
    "clip-08-ronald-reagan-ufo-area-51": "Pidato Ronald Reagan di PBB 1987: 'kalau ada ancaman alien dari luar dunia, perbedaan kita lenyap' — kutipan aslinya dibacakan; lalu Area 51: hangar UFO yang katanya dikasih lihat lengkap dengan 'tutorial nyetir UFO' bentuk kapsul yang viral dari TikTok",
    "clip-09-dajjal-era-teknologi-illuminati": "Era teknologi vs kepercayaan: hadits dajal dan ciri-cirinya vs deepfake & AI yang bikin pusing mana nyata mana palsu; kalau 'mesej langit' benar muncul, dugaan Nessie: bukan menyatukan malah perpecahan dan perang; sejarah illuminati dari gerakan pencerahan yang dicap anti-Tuhan — pelajaran buat siapa pun yang beda",
    "clip-10-rahasia-sulap-verdict-bluebeam": "Sisi lain Deddy: rahasia dunia sulap — 'kita main di area tengah-tengah', tidak pernah bilang supranatural tapi juga tidak boleh bilang itu trik; cerita The Next Mentalist dan aksi Rihanna live; lalu verdict Blue Beam: murni teori konspirasi tanpa bukti empiris",
    "clip-11-gempa-asli-north-korea-star-trek": "Senjata pemusnah yang 'lagi di-reset' — atau sekadar bluffing ala parade senjata Korea Utara? Verdict Deddy: gempa kemarin memang gempa asli, TAPI teknologi semacam itu bisa dikembangkan; nostalgia Star Trek: alat komunikator yang dulu mustahil kini jadi handphone di tangan kita",
    "clip-12-percaya-gak-nyampe-bulan": "Pertanyaan panas: 'Kamu percaya gak pernah nyampe bulan?' — Apollo mendarat 6 kali (1969-1972) dengan 12 astronot; komputer Apollo cuma RAM 4 kilobyte, sementara sekarang orang malah tak kunjung balik; plus teori 'alien-nya orang diculik' era perang dingin",
    "clip-13-video-ufo-resmi-angkatan-udara": "Kenapa isu alien yang dulu cuma bahan candaan tiba-tiba jadi serius? Video resmi angkatan udara AS ketemu unidentified flying object; undang-undang transparansi yang membuka dokumen — tapi kenapa baru sekarang dibahas?",
    "clip-14-6-gunung-erupsi-geomagnetik": "Teori 'kita kena kutuk': 6 gunung berapi erupsi beruntun — lalu podcast Deddy dengan Prof. Daniel menyentil pembalikan geomagnetik: proses nyata, berulang tiap ±500 ribu tahun, butuh ribuan tahun (bukan instan); efek ke manusia, kompas, pesawat, dan banking — plus nama ilmiahnya: Brunhes-Matuyama",
    "clip-15-ai-melawan-alien-verdict": "Penutup: postingan teman di perusahaan AI besar — 'kita beruntung kalau bisa selamat sampai akhir dekade ini'; teori AI dipersiapkan untuk melawan alien ala Skynet; dari AGI ke ASI cuma butuh waktu pendek; Blake Lemoine insinyur Google yang yakin AI sudah 'merasa hidup'; verdict akhir Nessie: semua bencana yang terjadi masih bisa dijelaskan secara ilmiah — dan pesan penutup: banyak-banyak berdoa, magnet bumi bakal kebalik",
}

os.makedirs("out", exist_ok=True)
uploaded = []
if os.path.exists("out/uploaded.json"):
    uploaded = json.load(open("out/uploaded.json"))

clips = []
for u in uploaded:
    cid = u["id"]
    clips.append({
        "file": u["file"],
        "topik": TOPIK.get(cid, ""),
        "durasi_detik": u["durasi"],
        "part_sumber": u["part"],
    })

meta = {
    "sesi": SESI,
    "tanggal": "2026-09-24",
    "sumber": GEM,
    "spesifikasi": {
        "resolusi": "1080x1920",
        "fps": 30,
        "layout": "kertas krem + grain (video card tengah full-width, posisi centerY 0.44)",
        "caption": "popup karaoke Bahasa Indonesia, 2-4 kata per grup — UPGRADE sesi ini: kata MENYALA KUNING saat diucapkan (mengikuti irama bicara per kata, transisi cepat putih->kuning), kata aktif membesar + glow, kata yang sudah diucap tetap kuning sampai popup keluar",
        "watermark": "@ofkiehme",
    },
    "clips": clips,
}
json.dump(meta, open("out/metadata.json", "w"), ensure_ascii=False, indent=1)
print(f"metadata.json diupdate: {len(clips)} klip ter-upload")
