#!/usr/bin/env bash
# ============================================================
#  RENDER dengan auto-retry (untuk klip panjang / sandbox terbatas)
# ============================================================
#  render-segments.mjs sudah IDEMPOTEN (segmen yang sudah ada
#  dilewati), tapi kalau proses mati di tengah (crash Chrome,
#  proses sandbox dibunuh, dll) agent biasanya harus nunggu lama
#  atau nebak-nebak kapan harus panggil ulang. Script ini yang
#  mengulang otomatis sampai SEMUA segmen selesai atau batas
#  percobaan tercapai — jadi sekali panggil, tunggu, selesai.
#
#  WAJIB dijalankan foreground (bukan `&`) — proses background
#  dibunuh sandbox saat tool call berakhir (lihat §5 CATATAN-TEKNIS.md).
#
#  Pemakaian:
#    bash scripts/render-retry.sh video-utuh          # -> out/data/video-utuh.json
#    bash scripts/render-retry.sh video-utuh 8         # maks 8 percobaan (default 5)
# ============================================================
set -uo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."

DATA_NAME="${1:?Pemakaian: bash scripts/render-retry.sh <nama-data-tanpa-.json> [maks-percobaan]}"
MAX_TRIES="${2:-5}"
DATA_FILE="out/data/${DATA_NAME}.json"
LOG_FILE="out-render-${DATA_NAME}.log"

[ -f "$DATA_FILE" ] || { echo "Data tidak ada: $DATA_FILE (jalankan 'npm run build-data' dulu)"; exit 1; }

# safety-net: buang sisa bundle Remotion lama di /tmp dari SEBELUM fix outDir
# tetap ada (mis. sandbox lama / cache-pack lama). Bundle aktif sekarang selalu
# di .remotion-bundle/ (root project), bukan di /tmp lagi. Lihat CATATAN-TEKNIS.md §13.
find /tmp -maxdepth 1 -iname "remotion-*" -mmin +5 -exec rm -rf {} + 2>/dev/null || true

n=1
while [ "$n" -le "$MAX_TRIES" ]; do
  echo "=== render percobaan $n/$MAX_TRIES ($(date +%H:%M:%S)) ==="
  node scripts/render-segments.mjs "${DATA_NAME}.json" > "$LOG_FILE" 2>&1
  STATUS=$?
  tail -n 15 "$LOG_FILE"

  if [ "$STATUS" -eq 0 ] && grep -Eq "selesai|tidak ada yang perlu dilakukan" "$LOG_FILE"; then
    echo "✓ render selesai (percobaan $n)"
    exit 0
  fi

  echo "! render belum selesai / exit code $STATUS — cek $LOG_FILE, retry (segmen yang sudah ada otomatis dilewati)"
  n=$((n + 1))
  sleep 2
done

echo "✗ masih belum selesai setelah $MAX_TRIES percobaan."
echo "  Cek manual: tail -c 600 $LOG_FILE"
echo "  Segmen yang sudah jadi ada di out/segments/ (tidak perlu diulang, aman lanjut lagi)."
exit 1
