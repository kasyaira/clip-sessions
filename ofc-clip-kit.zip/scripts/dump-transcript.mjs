#!/usr/bin/env node
/** Dump transkrip per jendela 20s utk baca topik + tentukan batas klip */
import fs from 'node:fs';
const {words} = JSON.parse(fs.readFileSync('out/transcripts/raw.json', 'utf8'));
const WIN = 20; // detik per baris
let win = 0;
let line = [];
const flush = () => {
  if (line.length) {
    const t0 = (win * WIN);
    const mm = String(Math.floor(t0 / 60)).padStart(2, '0');
    const ss = String(Math.floor(t0 % 60)).padStart(2, '0');
    console.log(`[${mm}:${ss}] ${line.join(' ')}`);
  }
  line = [];
};
for (const w of words) {
  const wWin = Math.floor(w.start / WIN);
  if (wWin !== win) { flush(); win = wWin; }
  line.push(w.text);
}
flush();
