#!/usr/bin/env bash
# ============================================================
#  UPLOAD FILE KE GitHub (kasyaira/clip-sessions) via Contents API
#  Upload satu file, langsung ter-commit. Aman diulang (update
#  kalau file sudah ada via sha).
#
#  Pemakaian:
#    bash scripts/upload-github.sh <file_lokal> <path_di_repo> [pesan_commit]
#  Contoh:
#    bash scripts/upload-github.sh out/clips/clip-01.mp4 \
#         "sesi-07-nessie-judge/clip-01-judul.mp4" "clip-01"
# ============================================================
set -uo pipefail
FILE="${1:?file lokal wajib}"
REPO_PATH="${2:?path di repo wajib}"
MSG="${3:-"upload ${REPO_PATH}"}"
OWNER="kasyaira"
REPO="clip-sessions"
TOKEN="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"
API="https://api.github.com/repos/${OWNER}/${REPO}/contents/${REPO_PATH}"

[ -f "$FILE" ] || { echo "ERROR: file tidak ada: $FILE"; exit 1; }
SIZE=$(stat -c %s "$FILE")
echo "[upload] $FILE ($((SIZE/1024/1024))MB) -> $REPO_PATH"

# cek apakah file sudah ada (butuh sha untuk update)
SHA=$(curl -s --max-time 30 -H "Authorization: Bearer $TOKEN" "$API" \
  | python3 -c "import json,sys
try:
  d=json.load(sys.stdin)
  print(d.get('sha') or '')
except Exception:
  print('')" 2>/dev/null)
[ -n "$SHA" ] && echo "[upload] file sudah ada di repo, update (sha ${SHA:0:8}...)"

# body JSON: content base64 disimpan via file (hindari env/arg raksasa)
base64 -w 0 "$FILE" > /tmp/upload-b64.txt
python3 - "$MSG" "$SHA" <<'EOF' > /tmp/upload-body.json
import json, sys
msg, sha = sys.argv[1], sys.argv[2]
body = {"message": msg, "branch": "main"}
if sha:
    body["sha"] = sha
with open("/tmp/upload-b64.txt") as f:
    body["content"] = f.read().strip()
json.dump(body, sys.stdout)
EOF
rm -f /tmp/upload-b64.txt

# PUT upload
RESP=$(curl -s --max-time 300 -X PUT \
  -H "Authorization: Bearer $TOKEN" \
  -H "Accept: application/vnd.github+json" \
  -H "Content-Type: application/json" \
  --data-binary @/tmp/upload-body.json \
  "$API")

OK=$(echo "$RESP" | python3 -c "import json,sys
try:
  d=json.load(sys.stdin)
  print('OK' if (d.get('content') or d.get('commit')) else 'FAIL: '+json.dumps(d)[:300])
except Exception as e:
  print('FAIL parse: '+str(e))" 2>/dev/null)
echo "[upload] hasil: $OK"
rm -f /tmp/upload-body.json
case "$OK" in
  OK*) exit 0 ;;
  *) exit 1 ;;
esac
