#!/usr/bin/env node
/** Tampil kata + timestamp di sekitar waktu tertentu (untuk pilih batas klip presisi)
 *  Pemakaian: node scripts/words-around.mjs <detik> <jendela_detik> */
import fs from 'node:fs';
const {words} = JSON.parse(fs.readFileSync('out/transcripts/raw.json', 'utf8'));
const t = Number(process.argv[2] ?? 0);
const win = Number(process.argv[3] ?? 8);
const lo = t - win / 2, hi = t + win / 2;
for (const w of words) {
  if (w.end < lo || w.start > hi) continue;
  const s = w.start.toFixed(2).padStart(8);
  const e = w.end.toFixed(2).padStart(7);
  console.log(`${s}-${e}  ${w.text}`);
}
