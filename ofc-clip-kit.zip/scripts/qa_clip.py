#!/usr/bin/env python3
"""QA piksel cepat: ekstrak frame dari klip, hitung piksel kuning #FFD60A
di area subtitle (bawah 45% frame). >50 piksel = word-highlight jalan (§15)."""
import subprocess, sys, os, tempfile
from PIL import Image

def qa(clip_path, offsets):
    results = []
    for t in offsets:
        with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as f:
            tmp = f.name
        r = subprocess.run(['ffmpeg', '-y', '-v', 'error', '-ss', str(t),
                            '-i', clip_path, '-frames:v', '1', tmp],
                           capture_output=True)
        if r.returncode != 0 or not os.path.exists(tmp):
            results.append((t, 'ERR', 0)); continue
        img = Image.open(tmp).convert('RGB')
        w, h = img.size
        crop = img.crop((0, int(h*0.55), w, h))  # area subtitle (bawah)
        px = crop.load()
        yellow = 0
        for y in range(crop.size[1]):
            for x in range(crop.size[0]):
                r_, g_, b_ = px[x, y]
                if 240 <= r_ <= 255 and 200 <= g_ <= 230 and 0 <= b_ <= 40:
                    yellow += 1
        os.unlink(tmp)
        results.append((t, 'OK' if yellow > 50 else 'LOW', yellow))
    return results

if __name__ == '__main__':
    clip = sys.argv[1]
    offs = [float(x) for x in sys.argv[2:]] or [30.5, 80.5, 140.5]
    dur = float(subprocess.run(['ffprobe', '-v', 'error', '-show_entries',
        'format=duration', '-of', 'csv=p=0', clip], capture_output=True,
        text=True).stdout.strip().rstrip(','))
    offs = [min(o, dur-0.5) for o in offs if o < dur - 0.3]
    ok = True
    for t, status, n in qa(clip, offs):
        print(f'  {t:7.1f}s  {status}  kuning={n}')
        if status != 'OK': ok = False
    print('QA:', 'LULUS' if ok else 'PERIKSA (cek frame tetangga §20.6)')
