#!/usr/bin/env bash
# ============================================================
#  BOOTSTRAP — satu perintah untuk siapkan seluruh environment
# ============================================================
#  Kenapa script ini ada:
#  Sandbox agent (mis. GLM) sering di-reset total setiap beberapa
#  jam tidak dipakai — node_modules, whisper.cpp (build), model
#  whisper, dan browser Chrome milik Remotion SEMUA hilang.
#  Tanpa script ini, agent harus research + build + download ulang
#  tiap sesi baru (menit sampai puluhan menit, dan sering gagal
#  di tengah jalan karena error yang sebenarnya sudah pernah
#  dipecahkan sebelumnya).
#
#  Script ini:
#    1. Kalau ada file cache-pack (clip-kit-cache.tar.gz) di root
#       project → EXTRACT (~detik), lewati semua build/download.
#    2. Kalau tidak ada → build semuanya dari nol SEKALI, dengan
#       retry otomatis + timeout per-langkah (supaya kalau network
#       macet, agent tahu dalam hitungan detik — bukan menunggu
#       sampai timeout tool call habis baru sadar harus retry).
#    3. Di akhir → BUAT cache-pack baru, supaya sesi berikutnya
#       (bahkan setelah sandbox di-reset) tinggal upload file itu
#       lagi dan bootstrap ini langsung skip ke mode cepat.
#
#  Pemakaian:
#    bash scripts/bootstrap.sh                # mode normal (whisper+browser)
#    bash scripts/bootstrap.sh --full         # + cache seluruh node_modules juga
#    bash scripts/bootstrap.sh --refresh-cache  # paksa buat ulang cache-pack
#
#  WAJIB dijalankan SEBELUM langkah manapun di AGENTS.md.
#  Jangan improvisasi cmake/whisper/npm manual — semua fix yang
#  terbukti (lihat CATATAN-TEKNIS.md) sudah otomatis di sini.
# ============================================================
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

CACHE_PACK="clip-kit-cache.tar.gz"
FULL_MODE=0
REFRESH_CACHE=0
for arg in "$@"; do
  case "$arg" in
    --full) FULL_MODE=1 ;;
    --refresh-cache) REFRESH_CACHE=1 ;;
  esac
done

T0=$(date +%s)
step() { echo; echo "▶ [$(( $(date +%s) - T0 ))s] $*"; }
ok()   { echo "  ✓ $*"; }
warn() { echo "  ! $*"; }

# retry <label> <timeout_detik> <percobaan> -- <command...>
retry() {
  local label="$1"; local tmo="$2"; local tries="$3"; shift 3
  [ "$1" = "--" ] && shift
  local n=1
  while [ "$n" -le "$tries" ]; do
    echo "  → $label (percobaan $n/$tries, timeout ${tmo}s)"
    if timeout "$tmo" "$@"; then
      ok "$label OK"
      return 0
    fi
    warn "$label gagal/timeout, retry dalam 3s..."
    sleep 3
    n=$((n + 1))
  done
  warn "$label GAGAL setelah $tries percobaan — lanjutkan manual, cek CATATAN-TEKNIS.md"
  return 1
}

step "0/6 cek dasar (node, npm, ffmpeg)"
node -v || { echo "node tidak ditemukan, tidak bisa lanjut"; exit 1; }
npm -v || true
command -v ffmpeg >/dev/null && ok "ffmpeg sistem ada" || warn "ffmpeg sistem tidak ada — fallback ke 'npx remotion ffmpeg' otomatis di transcribe.mjs"

# ------------------------------------------------------------
# 1) RESTORE dari cache-pack kalau ada (jalur cepat)
# ------------------------------------------------------------
RESTORED=0
if [ "$REFRESH_CACHE" -eq 0 ] && [ -f "$CACHE_PACK" ]; then
  step "1/6 ditemukan $CACHE_PACK — extract (jalur cepat, harusnya <1 menit)"
  if tar xzf "$CACHE_PACK"; then
    ok "cache-pack ter-extract: whisper.cpp/, node_modules/.remotion/$([ -d node_modules ] && echo ', node_modules/')"
    RESTORED=1
  else
    warn "gagal extract cache-pack, lanjut build dari nol"
  fi
else
  step "1/6 tidak ada cache-pack (atau --refresh-cache) — build dari nol"
fi

# ------------------------------------------------------------
# 2) node_modules (kalau belum ada / cache-pack tidak full)
# ------------------------------------------------------------
if [ -d node_modules ] && [ -f node_modules/.package-lock.json ]; then
  step "2/6 node_modules sudah ada, skip npm install"
else
  step "2/6 npm ci (fallback npm install)"
  retry "npm ci" 300 2 -- npm ci --no-audit --no-fund \
    || retry "npm install" 300 2 -- npm install --no-audit --no-fund
fi

# ------------------------------------------------------------
# 3) cmake tanpa sudo (WAJIB pip venv, JANGAN apt — lihat §2 CATATAN-TEKNIS.md)
# ------------------------------------------------------------
if [ -f whisper.cpp/main ] || [ -f whisper.cpp/build/bin/main ]; then
  step "3/6 whisper.cpp binary sudah ada, skip cmake"
else
  step "3/6 pastikan cmake ada (pip venv, bukan apt — tidak ada sudo di sandbox)"
  if command -v cmake >/dev/null; then
    ok "cmake sudah ada di PATH"
  else
    export PATH="$HOME/.venv/bin:$PATH"
    if command -v cmake >/dev/null; then
      ok "cmake ditemukan di ~/.venv/bin"
    else
      retry "pip install cmake" 120 2 -- pip install cmake
      export PATH="$HOME/.venv/bin:$PATH"
    fi
  fi
fi

# ------------------------------------------------------------
# 4) build whisper.cpp + download model (front-load, bukan lazy)
# ------------------------------------------------------------
if [ -f whisper.cpp/main ] || [ -f whisper.cpp/build/bin/main ]; then
  step "4/6 whisper.cpp + model sudah siap, skip"
else
  step "4/6 build whisper.cpp + download model (paling lama & paling sering gagal network)"
  export PATH="$HOME/.venv/bin:$PATH"
  retry "warm-whisper (build+model)" 600 3 -- node scripts/warm-whisper.mjs --model small
fi

# ------------------------------------------------------------
# 5) Chrome Headless Shell milik Remotion
#    (download ke node_modules/.remotion/chrome-headless-shell)
# ------------------------------------------------------------
if [ -d node_modules/.remotion/chrome-headless-shell ]; then
  step "5/6 Chrome headless shell sudah ada, skip"
else
  step "5/6 download Chrome headless shell (Remotion)"
  retry "remotion browser ensure" 300 3 -- npx remotion browser ensure
fi

# ------------------------------------------------------------
# 6) buat / refresh cache-pack untuk sesi berikutnya
# ------------------------------------------------------------
NEED_NEW_CACHE=0
[ "$REFRESH_CACHE" -eq 1 ] && NEED_NEW_CACHE=1
[ ! -f "$CACHE_PACK" ] && NEED_NEW_CACHE=1

if [ "$NEED_NEW_CACHE" -eq 1 ]; then
  step "6/6 bungkus cache-pack -> $CACHE_PACK"
  TAR_ARGS=()
  [ -d whisper.cpp ] && TAR_ARGS+=(whisper.cpp)
  [ -d node_modules/.remotion ] && TAR_ARGS+=(node_modules/.remotion)
  if [ "$FULL_MODE" -eq 1 ] && [ -d node_modules ]; then
    TAR_ARGS=(node_modules) # full mode: satu cache buat semuanya, whisper.cpp tetap ikut terpisah
    [ -d whisper.cpp ] && TAR_ARGS+=(whisper.cpp)
  fi
  if [ "${#TAR_ARGS[@]}" -gt 0 ]; then
    tar czf "${CACHE_PACK}.tmp" "${TAR_ARGS[@]}" && mv "${CACHE_PACK}.tmp" "$CACHE_PACK"
    SIZE=$(du -h "$CACHE_PACK" | cut -f1)
    ok "cache-pack siap: $CACHE_PACK ($SIZE)"
    echo
    echo "  ⚠ PENTING — sampaikan ke user:"
    echo "    Download file '$CACHE_PACK' ($SIZE) dari sandbox ini SEKARANG."
    echo "    Sesi berikutnya (setelah sandbox reset), upload file ini BERSAMA"
    echo "    zip project ke chat — bootstrap.sh akan extract-nya dalam hitungan"
    echo "    detik, tidak perlu build/download ulang whisper.cpp & Chrome."
  else
    warn "tidak ada yang bisa di-cache (whisper.cpp/node_modules/.remotion tidak ketemu)"
  fi
else
  step "6/6 cache-pack sudah ada dan valid, tidak dibuat ulang (pakai --refresh-cache untuk paksa)"
fi

echo
echo "=== bootstrap selesai dalam $(( $(date +%s) - T0 ))s ==="
[ "$RESTORED" -eq 1 ] && echo "(dipercepat lewat cache-pack)"
echo "Lanjut ke pipeline seperti biasa: lihat AGENTS.md langkah 1-4."
