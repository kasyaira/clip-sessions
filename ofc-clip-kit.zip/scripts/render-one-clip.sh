#!/usr/bin/env bash
# ============================================================
#  RENDER + FINALISASI SATU KLIP (resumable antar tool call)
# ============================================================
#  Pemakaian:
#    bash scripts/render-one-clip.sh <nama-data-tanpa-.json>
#
#  Alur:
#    1. Kalau out/clips/<id>.mp4 sudah ada -> selesai (exit 0)
#    2. Segmen klip sebelumnya dibuang (marker FOR-CLIP di out/segments)
#    3. Render segmen pending (--reuse-bundle, hemat 2-4 menit/panggilan)
#       — kalau tool call terbunuh di tengah, panggil LAGI script ini,
#         segmen yang sudah jadi otomatis dilewati.
#    4. Semua segmen selesai -> concat + mux audio asli -> out/clips/<id>.mp4
#
#  Exit code: 0 = klip final siap; 2 = masih ada segmen pending.
# ============================================================
set -uo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")/.."

ID="${1:?Pemakaian: bash scripts/render-one-clip.sh <nama-data-tanpa-.json>}"
DATA="out/data/${ID}.json"
SEGD="out/segments"
[ -f "$DATA" ] || { echo "ERROR: data tidak ada: $DATA"; exit 1; }

FINAL="out/clips/${ID}.mp4"
if [ -f "$FINAL" ]; then
  echo "DONE_ALREADY $FINAL ($(stat -c %s "$FINAL") bytes)"
  exit 0
fi

# --- isolasi segmen per klip ---
mkdir -p "$SEGD" out/tmp out/clips
MARKER="$SEGD/FOR-CLIP"
CUR="$(cat "$MARKER" 2>/dev/null || true)"
if [ "$CUR" != "$ID" ]; then
  if [ -n "$CUR" ]; then
    echo "[clip] buang segmen klip sebelumnya ($CUR)"
  fi
  rm -rf "$SEGD"
  mkdir -p "$SEGD"
  echo "$ID" > "$MARKER"
fi

# --- baca info klip dari data ---
read CLIP_START CLIP_END < <(python3 -c "
import json
d=json.load(open('$DATA'))
print(d['clipStart'], d['clipEnd'])")
DUR=$(python3 -c "print(round($CLIP_END - $CLIP_START + 0.45, 3))")
echo "[clip] $ID: sumber $CLIP_START-$CLIP_END, durasi render $DUR s"

# --- render segmen pending (sekali panggil; kalau kebunuh, ulangi script ini) ---
node scripts/render-segments.mjs "${ID}.json" --reuse-bundle 2>&1 | grep -vE "^\[segmen\]   [0-9]+%" | tail -12
PIPE=${PIPESTATUS[0]}

# --- cek kelengkapan segmen ---
TOTAL_SEG=$(python3 - "$ID" <<'EOF'
import json, math, sys
d = json.load(open(f"out/data/{sys.argv[1]}.json"))
frames = math.ceil((d['clipEnd'] - d['clipStart'] + 0.45) * 30)
print(math.ceil(frames / 1584))
EOF
)
HAVE=0
for f in "$SEGD"/seg-*.mp4; do [ -f "$f" ] && HAVE=$((HAVE+1)); done 2>/dev/null
echo "[clip] segmen: $HAVE/$TOTAL_SEG"
if [ "$HAVE" -lt "$TOTAL_SEG" ] || [ "$PIPE" -ne 0 ]; then
  echo "PENDING $HAVE/$TOTAL_SEG segmen selesai — panggil script ini lagi untuk lanjut."
  exit 2
fi

# --- semua segmen siap: concat + mux audio + re-encode (kompresi final) ---
echo "[clip] gabung segmen + mux audio..."
ls "$SEGD"/seg-*.mp4 | sort | xargs -n1 basename | sed "s/^/file '/;s/$/'/" > "$SEGD/concat.txt"
ffmpeg -y -v error -f concat -safe 0 -i "$SEGD/concat.txt" -c:v copy "out/tmp/${ID}-nosound.mp4"
ffmpeg -y -v error -ss "$CLIP_START" -t "$DUR" -i public/input/raw.mp4 -vn -c:a copy "out/tmp/${ID}-audio.m4a"
ffmpeg -y -v error -i "out/tmp/${ID}-nosound.mp4" -i "out/tmp/${ID}-audio.m4a" -map 0:v -map 1:a -c copy -shortest "out/tmp/${ID}-big.mp4"
rm -f "out/tmp/${ID}-nosound.mp4" "out/tmp/${ID}-audio.m4a" "$SEGD/concat.txt"

# re-encode final: hasil render remotion ~2.9Mbps terlalu besar utk klip 4-5 menit
# (>100MB, lewat batas GitHub API). CRF 24 veryfast -> ~1.4Mbps, kualitas visual
# podcast nyaris identik, ukuran sepadan dgn sesi-sesi sebelumnya (21-33MB).
# CATATAN: watchdog sandbox kadang SIGKILL shell tepat setelah encode selesai
# (file tetap utuh) -> JANGAN percaya exit code, selalu verifikasi file akhir.
if [ -f "out/tmp/${ID}-big.mp4" ]; then
  echo "[clip] re-encode final (CRF 24)..."
  ffmpeg -y -v error -i "out/tmp/${ID}-big.mp4" -c:v libx264 -crf 24 -preset veryfast -c:a copy "$FINAL" || true
  sleep 1
fi

# --- verifikasi final (durasi harus mendekati target) ---
if [ -f "$FINAL" ]; then
  OKDUR=$(ffprobe -v error -show_entries format=duration -of csv=p=0 "$FINAL" 2>/dev/null | python3 -c "
import sys
try:
  d=float(sys.stdin.read().strip())
  print('OK' if abs(d-$DUR)<3 else 'BAD')
except Exception:
  print('BAD')")
  if [ "$OKDUR" = "OK" ]; then
    rm -f "out/tmp/${ID}-big.mp4"
    echo "DONE $FINAL ($(stat -c %s "$FINAL") bytes, durasi OK)"
    exit 0
  else
    echo "ERROR: durasi final tidak wajar (harus ~$DUR s)"
    exit 1
  fi
else
  # mungkin watchdog membunuh shell tepat sebelum rename selesai — cek file besar
  if [ -f "out/tmp/${ID}-big.mp4" ]; then
    echo "KILLED_MID_ENCODE — panggil script ini lagi untuk ulang re-encode"
  fi
  echo "ERROR: finalisasi gagal"
  exit 1
fi
