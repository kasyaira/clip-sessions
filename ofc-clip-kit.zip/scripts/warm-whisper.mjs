#!/usr/bin/env node
/**
 * ============================================================
 *  WARM-UP WHISPER.CPP (dipanggil oleh scripts/bootstrap.sh)
 * ============================================================
 *  Memaksa build whisper.cpp + download model TERJADI SEKARANG,
 *  bukan nanti pas transcribe.mjs jalan pertama kali. Tujuannya
 *  supaya bootstrap.sh bisa mengukur waktunya, retry kalau gagal,
 *  dan langsung mem-bungkus hasilnya ke cache-pack.
 *
 *  Tidak butuh video sama sekali. Aman dipanggil berkali-kali
 *  (idempoten) — kalau whisper.cpp/model sudah ada, SDK-nya
 *  sendiri yang skip.
 *
 *  Pemakaian:
 *    node scripts/warm-whisper.mjs [--model small]
 * ============================================================
 */
import whisperSdk from '@remotion/install-whisper-cpp';

const WHISPER_CPP_VERSION = '1.7.3'; // JANGAN naikkan, lihat CATATAN-TEKNIS.md §2
const WHISPER_DIR = 'whisper.cpp';
const {installWhisperCpp, downloadWhisperModel} = whisperSdk;

const args = process.argv.slice(2);
let model = 'small';
for (let i = 0; i < args.length; i++) {
  if (args[i] === '--model') model = args[++i];
}

console.log(`[warm-whisper] 1/2 pastikan whisper.cpp v${WHISPER_CPP_VERSION} ter-build...`);
await installWhisperCpp({
  version: WHISPER_CPP_VERSION,
  to: WHISPER_DIR,
  printOutput: true,
});

console.log(`[warm-whisper] 2/2 pastikan model "${model}" terdownload...`);
await downloadWhisperModel({
  model,
  folder: WHISPER_DIR,
  printOutput: true,
});

console.log('[warm-whisper] selesai — whisper.cpp siap dipakai (build & model sudah di-cache lokal).');
