#!/usr/bin/env node
/** QA visual cepat: render beberapa frame PNG dari data klip utk cek highlight kuning */
import fs from 'node:fs';
import path from 'node:path';
import {bundle} from '@remotion/bundler';
import {renderStill, selectComposition} from '@remotion/renderer';

const dataFile = process.argv[2] ?? 'clip-05-tertarik-masuk-politik';
const frames = process.argv.slice(3).map(Number);
const data = JSON.parse(fs.readFileSync(path.join('out/data', dataFile + '.json'), 'utf8'));
const project = JSON.parse(fs.readFileSync('src/project.json', 'utf8'));

console.log('[qa] bundling...');
const BUNDLE_DIR = path.resolve('.remotion-bundle');
let serveUrl;
if (fs.existsSync(path.join(BUNDLE_DIR, 'index.html'))) {
  serveUrl = BUNDLE_DIR;
  console.log('[qa] pakai bundle yang sudah ada (.remotion-bundle/)');
} else {
  fs.rmSync(BUNDLE_DIR, {recursive: true, force: true});
  serveUrl = await bundle({entryPoint: path.resolve('src/index.ts'), outputDir: BUNDLE_DIR});
}
const composition = await selectComposition({
  serveUrl, id: project.compositionId, inputProps: {data},
  chromiumOptions: {enableMultiProcessOnLinux: true},
});
fs.mkdirSync('out/qa', {recursive: true});
for (const f of frames) {
  await renderStill({
    composition, serveUrl, inputProps: {data},
    frame: f,
    output: `out/qa/${dataFile}-f${String(f).padStart(4, '0')}.png`,
    imageFormat: 'png',
    chromiumOptions: {enableMultiProcessOnLinux: true},
  });
  console.log(`[qa] OK frame ${f}`);
}
