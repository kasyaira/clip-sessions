#!/usr/bin/env node
/**
 * Download YouTube video via loader.to API (proven method, see CARA-KERJA.md §2)
 * Usage: node loader-download.mjs <youtube_url> <output_file> [format]
 * format: 360 | 480 | 720 | 1080 (default 720)
 */
import { writeFileSync, existsSync, statSync, renameSync } from 'node:fs';

const [, , url, out, formatArg] = process.argv;
const format = formatArg || '720';
if (!url || !out) {
  console.error('usage: node loader-download.mjs <url> <out> [format]');
  process.exit(1);
}

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function startDownload() {
  const u = `https://loader.to/ajax/download.php?format=${format}&url=${encodeURIComponent(url)}`;
  console.log('[1] start:', u);
  const res = await fetch(u, { headers: { 'User-Agent': UA } });
  const j = await res.json();
  console.log(JSON.stringify(j).slice(0, 300));
  if (!j.success || !j.id) throw new Error('start failed: ' + JSON.stringify(j).slice(0, 200));
  return j.id;
}

async function poll(id) {
  const t0 = Date.now();
  while (Date.now() - t0 < 10 * 60 * 1000) {
    await sleep(3000);
    const res = await fetch(`https://loader.to/ajax/progress.php?id=${id}`, {
      headers: { 'User-Agent': UA },
    });
    const j = await res.json();
    const pct = j.progress ? (j.progress / 10).toFixed(1) : '?';
    process.stdout.write(`\r[2] progress: ${pct}%  ${j.text || ''}          `);
    if (j.download_url) {
      console.log('\n[2] got download_url');
      return j.download_url;
    }
    if (j.error) throw new Error('progress error: ' + JSON.stringify(j));
  }
  throw new Error('timeout polling progress');
}

async function fetchFile(dlUrl, outFile) {
  console.log('[3] downloading file ...');
  const res = await fetch(dlUrl, { headers: { 'User-Agent': UA } });
  if (!res.ok) throw new Error('download HTTP ' + res.status);
  const total = +(res.headers.get('content-length') || 0);
  let got = 0;
  const tmp = outFile + '.part';
  const fh = (await import('node:fs')).createWriteStream(tmp);
  for await (const chunk of res.body) {
    fh.write(chunk);
    got += chunk.length;
    if (total) process.stdout.write(`\r[3] ${(got / 1024 / 1024).toFixed(1)}/${(total / 1024 / 1024).toFixed(1)} MB`);
    else process.stdout.write(`\r[3] ${(got / 1024 / 1024).toFixed(1)} MB`);
  }
  await new Promise((r) => fh.end(r));
  renameSync(tmp, outFile);
  const sz = statSync(outFile).size;
  console.log(`\n[3] done: ${outFile} (${(sz / 1024 / 1024).toFixed(1)} MB)`);
  if (sz < 1024 * 100) throw new Error('file too small, probably error page');
  return outFile;
}

const id = await startDownload();
const dl = await poll(id);
await fetchFile(dl, out);
console.log('SUCCESS');
