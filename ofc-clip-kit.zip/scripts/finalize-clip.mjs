#!/usr/bin/env node
/**
 * ============================================================
 *  FINALISASI KLIP — concat segmen (muted) + mux audio asli
 * ============================================================
 *  render-segments.mjs menghasilkan out/segments/seg-*.mp4 tanpa
 *  audio (idempoten per segmen). Script ini:
 *    1. concat semua segmen (copy, tanpa re-encode video)
 *    2. ambil audio dari video sumber pada rentang klip
 *       (clipStart - lead, durasi clipEnd - clipStart + lead + tail)
 *    3. mux jadi out/clips/<id>.mp4 (+faststart utk streaming)
 *
 *  Pemakaian:
 *    node scripts/finalize-clip.mjs <clip-id>
 */
import fs from 'node:fs';
import path from 'node:path';
import {execSync} from 'node:child_process';

const id = process.argv[2];
if (!id) {
  console.error('Pemakaian: node scripts/finalize-clip.mjs <clip-id>');
  process.exit(1);
}
const dataFile = path.join('out/data', `${id}.json`);
if (!fs.existsSync(dataFile)) {
  console.error('Data tidak ada:', dataFile);
  process.exit(1);
}
const data = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
const project = JSON.parse(fs.readFileSync('src/project.json', 'utf8'));
const FPS = 30;
const {lead, tail} = {lead: project.lead, tail: project.tail};

const totalFrames = Math.ceil((data.clipEnd - data.clipStart + lead + tail) * FPS);

// kumpulkan segmen yang ada, urut berdasar frame awal
const segDir = 'out/segments';
if (!fs.existsSync(segDir)) {
  console.error('Folder segmen tidak ada:', segDir);
  process.exit(1);
}
const segs = fs.readdirSync(segDir)
  .filter((f) => /^seg-\d{5}\.mp4$/.test(f))
  .sort();
if (segs.length === 0) {
  console.error('Tidak ada segmen ter-render di out/segments/');
  process.exit(1);
}

// validasi jumlah frame tiap segmen (harus sesuai rencana)
const expectRanges = [];
for (let s = 0; s < totalFrames; s += 1584) {
  expectRanges.push([s, Math.min(s + 1584 - 1, totalFrames - 1)]);
}
if (segs.length !== expectRanges.length) {
  console.warn(`[final] !! jumlah segmen ${segs.length} != ekspektasi ${expectRanges.length} — render belum lengkap?`);
}
let frameCount = 0;
for (const f of segs) {
  const out = execSync(
    `ffprobe -v error -select_streams v -show_entries stream=nb_frames -of csv=p=0 "${path.join(segDir, f)}"`
  ).toString();
  const n = Number((out.match(/\d+/) || ['0'])[0]);
  frameCount += n;
}
console.log(`[final] ${segs.length} segmen, total ${frameCount} frame (target ${totalFrames})`);
if (frameCount !== totalFrames) {
  console.error('[final] !! jumlah frame tidak cocok — jangan finalize, lanjut render-retry dulu');
  process.exit(1);
}

fs.mkdirSync('out/clips', {recursive: true});
fs.mkdirSync('out/tmp/finalize', {recursive: true});
const concatList = path.join('out/tmp/finalize', `${id}-concat.txt`);
fs.writeFileSync(concatList, segs.map((f) => `file '${path.resolve(segDir, f)}'`).join('\n'));

const concatMp4 = path.join('out/tmp/finalize', `${id}-video.mp4`);
const audioM4a = path.join('out/tmp/finalize', `${id}-audio.m4a`);
const outFile = path.join('out/clips', `${id}.mp4`);

// 1) concat video (copy)
console.log('[final] 1/3 concat segmen (video copy)...');
execSync(`ffmpeg -y -f concat -safe 0 -i "${concatList}" -c copy "${concatMp4}"`, {stdio: 'ignore'});

// 2) audio dari sumber
console.log('[final] 2/3 ekstrak audio dari sumber...');
const audioStart = Math.max(0, data.clipStart - lead);
const audioDur = totalFrames / FPS;
execSync(
  `ffmpeg -y -ss ${audioStart.toFixed(3)} -t ${audioDur.toFixed(3)} -i "${path.join('public', data.video)}" -vn -c:a aac -b:a 192k "${audioM4a}"`,
  {stdio: 'ignore'}
);

// 3) mux
console.log('[final] 3/3 mux video + audio...');
execSync(
  `ffmpeg -y -i "${concatMp4}" -i "${audioM4a}" -map 0:v:0 -map 1:a:0 -c:v copy -c:a copy -movflags +faststart "${outFile}"`,
  {stdio: 'ignore'}
);

const sz = fs.statSync(outFile).size;
const dur = execSync(`ffprobe -v error -show_entries format=duration -of csv=p=0 "${outFile}"`).toString().trim();
console.log(`[final] OK -> ${outFile} (${(sz / 1024 / 1024).toFixed(1)} MB, ${dur}s)`);
