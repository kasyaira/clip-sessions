#!/usr/bin/env node
/**
 * ============================================================
 *  FINALISASI SATU KLIP — gabung segmen + mux audio sumber
 * ============================================================
 *  Dipakai setelah `render-segments.mjs <klip>.json` selesai
 *  (semua segmen ada di out/segments/<klip>/).
 *
 *  Video segmen dirender MUTED; audio utuh diambil langsung dari
 *  video sumber di rentang [clipStart-lead, clipEnd+tail] — bebas
 *  glitch AAC di batas segmen.
 *
 *  Pemakaian:
 *    node scripts/finalize-clip.mjs <nama-data-tanpa-.json>
 * ============================================================
 */
import fs from 'node:fs';
import path from 'node:path';
import {execSync} from 'node:child_process';

const SEG_FRAMES = 1584; // HARUS sama dengan render-segments.mjs
const FPS = 30;

const dataName = (process.argv[2] ?? '').replace(/\.json$/, '');
if (!dataName) {
  console.error('Pemakaian: node scripts/finalize-clip.mjs <nama-data>');
  process.exit(1);
}
const dataPath = path.join('out/data', `${dataName}.json`);
if (!fs.existsSync(dataPath)) {
  console.error(`Data tidak ada: ${dataPath}`);
  process.exit(1);
}
const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
const project = JSON.parse(fs.readFileSync('src/project.json', 'utf8'));

const segDir = path.join('out/segments', dataName);
if (!fs.existsSync(segDir)) {
  console.error(`Folder segmen tidak ada: ${segDir} (jalankan render-segments dulu)`);
  process.exit(1);
}

const totalFrames = Math.ceil(
  (data.clipEnd - data.clipStart + project.lead + project.tail) * FPS
);
const expected = [];
for (let s = 0; s < totalFrames; s += SEG_FRAMES) expected.push(s);

const segs = fs
  .readdirSync(segDir)
  .filter((f) => /^seg-\d+\.mp4$/.test(f))
  .sort();

if (segs.length !== expected.length) {
  console.error(
    `Segmen belum lengkap: ada ${segs.length}/${expected.length} (${segs.join(', ')})`
  );
  process.exit(1);
}

// 1) concat video (codec copy — semua segmen dari encoder yang sama)
const listFile = path.join(segDir, 'concat.txt');
fs.writeFileSync(listFile, segs.map((s) => `file '${s}'`).join('\n'));
fs.mkdirSync('out/tmp', {recursive: true});
const nosound = path.join('out/tmp', `${dataName}.nosound.mp4`);
console.log(`[finalize ${dataName}] concat ${segs.length} segmen...`);
execSync(
  `ffmpeg -y -v error -f concat -safe 0 -i "${listFile}" -c:v copy "${nosound}"`
);

// 2) mux audio dari sumber, potong presisi di rentang klip
const start = Math.max(0, data.clipStart - project.lead);
const dur = data.clipEnd - data.clipStart + project.lead + project.tail;
fs.mkdirSync('out/clips', {recursive: true});
const out = path.join('out/clips', `${dataName}.mp4`);
console.log(`[finalize ${dataName}] mux audio sumber ${start.toFixed(2)}s +${dur.toFixed(2)}s...`);
execSync(
  `ffmpeg -y -v error -ss ${start} -t ${dur.toFixed(3)} -i public/input/raw.mp4 ` +
    `-i "${nosound}" -map 1:v -map 0:a -c:v copy -c:a aac -b:a 192k -shortest "${out}"`
);

// 3) verifikasi output
const probe = execSync(
  `ffprobe -v error -show_entries format=duration,size -of json "${out}"`
);
const meta = JSON.parse(probe.toString()).format;
console.log(
  `[finalize ${dataName}] OK -> ${out}  durasi ${parseFloat(meta.duration).toFixed(1)}s, ` +
    `${(meta.size / 1048576).toFixed(1)} MB`
);
