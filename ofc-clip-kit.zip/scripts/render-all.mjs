#!/usr/bin/env node
/**
 * ============================================================
 *  STEP 3 — RENDER BATCH
 * ============================================================
 *  Render semua klip dari out/data/*.json -> out/clips/<id>.mp4
 *  Output: 1080x1920 (portrait), 30fps, H.264 + audio asli.
 *
 *  Pemakaian:
 *    npm run render                  # render semua klip
 *    npm run render -- --only clip-01   # render satu klip saja
 * ============================================================
 */
import fs from 'node:fs';
import path from 'node:path';
import {bundle} from '@remotion/bundler';
import {renderMedia, selectComposition} from '@remotion/renderer';

const args = process.argv.slice(2);
let only = null;
for (let i = 0; i < args.length; i++) {
  if (args[i] === '--only') only = args[++i];
}

const project = JSON.parse(fs.readFileSync('src/project.json', 'utf8'));
const COMPOSITION_ID = project.compositionId;

const dataDir = 'out/data';
if (!fs.existsSync(dataDir)) {
  console.error('[render] folder out/data tidak ada — jalankan "npm run build-data" dulu.');
  process.exit(1);
}

let files = fs.readdirSync(dataDir).filter((f) => f.endsWith('.json'));
if (only) {
  files = files.filter((f) => f.replace(/\.json$/, '') === only);
}
if (files.length === 0) {
  console.error('[render] tidak ada file data untuk dirender.');
  process.exit(1);
}

console.log('[render] bundling project (sekali untuk semua klip)...');
// outDir TETAP — lihat catatan sama di render-segments.mjs (cegah /tmp penuh)
const BUNDLE_DIR = path.resolve('.remotion-bundle');
const serveUrl = await bundle({
  entryPoint: path.resolve('src/index.ts'),
  outDir: BUNDLE_DIR,
  onProgress: (p) => process.stdout.write(`\r[render] bundle ${Math.round(p * 100)}%`),
});
process.stdout.write('\n');

fs.mkdirSync('out/clips', {recursive: true});

for (const f of files) {
  const data = JSON.parse(fs.readFileSync(path.join(dataDir, f), 'utf8'));
  const inputProps = {data};

  console.log(`\n[render] ${data.id} (${(data.clipEnd - data.clipStart).toFixed(1)}s)...`);
  const composition = await selectComposition({
    serveUrl,
    id: COMPOSITION_ID,
    inputProps,
    // sandbox ini butuh multi-process: --single-process bikin render nyaris 1fps
    chromiumOptions: {enableMultiProcessOnLinux: true},
  });

  await renderMedia({
    composition,
    serveUrl,
    codec: 'h264',
    inputProps,
    outputLocation: path.join('out/clips', `${data.id}.mp4`),
    imageFormat: 'jpeg',
    jpegQuality: 90,
    concurrency: 2,
    x264Preset: 'veryfast',
    chromiumOptions: {enableMultiProcessOnLinux: true},
    overwrite: true,
    onProgress: ({progress}) =>
      process.stdout.write(`\r[render]   ${Math.round(progress * 100)}%`),
  });
  process.stdout.write('\n');
  console.log(`[render] OK -> out/clips/${data.id}.mp4`);
}

console.log('\n[render] semua klip selesai.');
