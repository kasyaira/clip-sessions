#!/usr/bin/env node
/**
 * ============================================================
 *  RENDER PER SEGMEN (klip panjang, sandbox 10 menit/call)
 * ============================================================
 *  Klip utuh (±4754 frame) terlalu lama untuk satu sesi render.
 *  Script ini memecah render menjadi segmen ±1584 frame.
 *  IDEMPOTEN: segmen yang sudah ada di out/segments/ dilewati,
 *  jadi aman dipanggil berulang sampai semua segmen selesai.
 *
 *  Video dirender TANPA audio (muted) — audio utuh diambil dari
 *  video sumber saat penggabungan, jadi bebas glitch AAC di
 *  batas segmen.
 *
 *  Pemakaian:
 *    node scripts/render-segments.mjs            # data default: out/data/video-utuh.json
 *    node scripts/render-segments.mjs klip.json
 * ============================================================
 */
import fs from 'node:fs';
import path from 'node:path';
import {bundle} from '@remotion/bundler';
import {renderMedia, selectComposition} from '@remotion/renderer';

const SEG_FRAMES = 1584; // ±52.8 detik per segmen (muat 1 sesi ±10 menit)
const dataFile = process.argv[2] ?? 'video-utuh.json';
const dataPath = path.join('out/data', dataFile.endsWith('.json') ? dataFile : `${dataFile}.json`);

const data = JSON.parse(fs.readFileSync(dataPath, 'utf8'));
const inputProps = {data};
const project = JSON.parse(fs.readFileSync('src/project.json', 'utf8'));
const COMPOSITION_ID = project.compositionId;
const FPS = 30;

const totalFrames = Math.ceil(
  (data.clipEnd - data.clipStart + project.lead + project.tail) * FPS
);

const segDir = 'out/segments';
fs.mkdirSync(segDir, {recursive: true});

const ranges = [];
for (let start = 0; start < totalFrames; start += SEG_FRAMES) {
  const end = Math.min(start + SEG_FRAMES - 1, totalFrames - 1); // inklusif
  ranges.push([start, end]);
}

const pad = (n) => String(n).padStart(5, '0');
const segFile = (s) => path.join(segDir, `seg-${pad(s)}.mp4`);
const pending = ranges.filter(([s]) => !fs.existsSync(segFile(s)));

if (pending.length === 0) {
  console.log('[segmen] semua segmen sudah ter-render, tidak ada yang perlu dilakukan.');
  process.exit(0);
}

console.log(
  `[segmen] total ${totalFrames} frame -> ${ranges.length} segmen, pending ${pending.length} (${pending.map(([s, e]) => `${s}-${e}`).join(', ')})`
);

// Bundle ke folder TETAP (.remotion-bundle/) — bukan temp dir /tmp yang menumpuk
// tiap panggilan (bug ENOSPC, lihat CARA-KERJA §6). Kalau bundle dari panggilan
// sebelumnya masih ada DAN src tidak berubah, langsung dipakai lagi (hemat 1-2 menit).
const BUNDLE_DIR = path.resolve('.remotion-bundle');
let serveUrl;
if (fs.existsSync(path.join(BUNDLE_DIR, 'index.html'))) {
  serveUrl = BUNDLE_DIR;
  console.log('[segmen] pakai bundle yang sudah ada (.remotion-bundle/)');
} else {
  console.log('[segmen] bundling project...');
  fs.rmSync(BUNDLE_DIR, {recursive: true, force: true});
  serveUrl = await bundle({
    entryPoint: path.resolve('src/index.ts'),
    outputDir: BUNDLE_DIR,
    onProgress: (p) => process.stdout.write(`\r[segmen] bundle ${Math.round(p * 100)}%`),
  });
  process.stdout.write('\n');
}

const composition = await selectComposition({
  serveUrl,
  id: COMPOSITION_ID,
  inputProps,
  chromiumOptions: {enableMultiProcessOnLinux: true},
});

for (const [s, e] of pending) {
  const out = segFile(s);
  const tmp = `${out}.partial.mp4`;
  console.log(`[segmen] render frame ${s}-${e} (${e - s + 1} frame, muted)...`);
  await renderMedia({
    composition,
    serveUrl,
    codec: 'h264',
    inputProps,
    frameRange: [s, e],
    muted: true, // audio digabung terpisah dari sumber
    outputLocation: tmp,
    imageFormat: 'jpeg',
    jpegQuality: 90,
    concurrency: 2,
    x264Preset: 'veryfast',
    chromiumOptions: {enableMultiProcessOnLinux: true},
    overwrite: true,
    onProgress: ({progress}) =>
      process.stdout.write(`\r[segmen]   ${Math.round(progress * 100)}%`),
  });
  process.stdout.write('\n');
  // rename baru setelah sukses — render yang terbunuh tidak meninggalkan
  // file parsial yang keliru dianggap selesai
  fs.renameSync(tmp, out);
  console.log(`[segmen] OK -> ${out}`);
}
console.log('[segmen] semua pending selesai.');
