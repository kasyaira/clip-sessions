#!/usr/bin/env node
/**
 * ============================================================
 *  STEP 1 — TRANSCRIBE
 * ============================================================
 *  Video mentah -> transkrip word-level timestamps (whisper.cpp).
 *  Output: out/transcripts/<nama-video>.json
 *  Format: { video, model, words: [{text, start, end}] }  (detik)
 *
 *  Pemakaian:
 *    npm run transcribe -- public/input/raw.mp4
 *    npm run transcribe -- public/input/raw.mp4 --model small
 *
 *  Model whisper (otomatis diunduh saat pertama kali):
 *    tiny (±75MB, cepat/kurang akurat) | base (±142MB)
 *    small (±466MB, seimbang — DEFAULT) | medium (±1.5GB, paling akurat)
 *
 *  Catatan: bahasa dideteksi otomatis oleh whisper (ID/EN/dll).
 *  Install pertama kali butuh internet + cmake (untuk build whisper.cpp).
 * ============================================================
 */
import fs from 'node:fs';
import path from 'node:path';
import {execSync} from 'node:child_process';
// API v4.0.526 (CommonJS): pakai default import + destructuring
// getWhisperCppVersion() sudah tidak ada di versi ini -> versi dipin hardcoded.
// v1.7.3 dipilih karena build `make` biasa menghasilkan binary `main` di root
// (sesuai getWhisperExecutablePath utk versi < 1.7.4).
import whisperSdk from '@remotion/install-whisper-cpp';

const WHISPER_CPP_VERSION = '1.7.3';
const WHISPER_DIR = 'whisper.cpp';
const {installWhisperCpp, downloadWhisperModel, transcribe} = whisperSdk;

const args = process.argv.slice(2);
const flags = {model: 'small', language: null};
const positional = [];
for (let i = 0; i < args.length; i++) {
  if (args[i] === '--model') {
    flags.model = args[++i];
  } else if (args[i] === '--language') {
    flags.language = args[++i]; // paksa bahasa, mis. id / en; null = auto-detect
  } else {
    positional.push(args[i]);
  }
}

const videoPath = positional[0];
if (!videoPath || !fs.existsSync(videoPath)) {
  console.error('[transcribe] video tidak ditemukan:', videoPath);
  console.error('Pemakaian: npm run transcribe -- public/input/raw.mp4');
  process.exit(1);
}

fs.mkdirSync('out/transcripts', {recursive: true});
fs.mkdirSync('out/tmp', {recursive: true});

const base = path.basename(videoPath, path.extname(videoPath));
const wavPath = path.join('out/tmp', `${base}.16k.wav`);

// 1) ekstrak audio 16kHz mono (whisper.cpp butuh format ini)
console.log('[transcribe] 1/4 ekstrak audio 16kHz mono...');
try {
  execSync(`ffmpeg -y -i "${videoPath}" -vn -acodec pcm_s16le -ar 16000 -ac 1 "${wavPath}"`, {
    stdio: 'ignore',
  });
} catch {
  console.log('[transcribe] ffmpeg sistem tidak ada, pakai ffmpeg bawaan remotion...');
  execSync(
    `npx remotion ffmpeg -y -i "${videoPath}" -vn -acodec pcm_s16le -ar 16000 -ac 1 "${wavPath}"`,
    {stdio: 'inherit'}
  );
}

// 2) siapkan whisper.cpp (di-cache, hanya lama di run pertama)
console.log('[transcribe] 2/4 siapkan whisper.cpp (sekali saja)...');
await installWhisperCpp({
  version: WHISPER_CPP_VERSION,
  to: WHISPER_DIR,
  printOutput: true,
});
console.log(`[transcribe] 2b/4 pastikan model ${flags.model} tersedia...`);
await downloadWhisperModel({
  model: flags.model,
  folder: WHISPER_DIR,
  printOutput: true,
});

// 3) transkrip dengan timestamp per token
console.log(`[transcribe] 3/4 transkrip (model=${flags.model})...`);

// cache hasil mentah whisper: iterasi berikutnya tidak perlu inferensi ulang
// (cache per model+language)
const cachePath = path.join(
  'out/tmp',
  `${base}.whisper-cache-${flags.model}-${flags.language ?? 'auto'}.json`
);
let rawJson;
if (fs.existsSync(cachePath)) {
  console.log('[transcribe] pakai cache whisper yang ada');
  rawJson = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
} else {
  rawJson = await transcribe({
    inputPath: path.resolve(wavPath), // absolut: binary whisper jalan dgn cwd=whisper.cpp
    whisperPath: WHISPER_DIR,
    whisperCppVersion: WHISPER_CPP_VERSION,
    model: flags.model,
    language: flags.language,
    printOutput: true,
    tokenLevelTimestamps: true,
  });
  fs.writeFileSync(cachePath, JSON.stringify(rawJson));
}
const {transcription} = rawJson;

// 4) gabungkan token jadi kata
//    token whisper: sub-kata, awal kata ditandai spasi/"▁", tanda baca nempel token sebelumnya
console.log('[transcribe] 4/4 gabungkan token jadi kata...');
const words = [];
const pushWord = (w) => {
  if (w && w.text.trim()) {
    words.push({
      text: w.text,
      start: Math.round(w.start * 1000) / 1000,
      end: Math.round(w.end * 1000) / 1000,
    });
  }
};

// accumulator DI LUAR loop segmen: dengan --max-len 1 tiap token = segmen
// sendiri, dan satu kata bisa membentang antar segmen (mis. ' t' + 'anya')
let cur = null;
for (const segment of transcription) {
  for (const tok of segment.tokens ?? []) {
    const raw = tok.text ?? '';
    if (!raw.trim()) continue;
    if (/^<\|.*\|>$/.test(raw.trim())) continue; // token spesial whisper
    if (/^\[_\w+\]$/.test(raw.trim())) continue; // [_BEG_], [_END_], [_TT_75], ...
    if (/\[_TT_\d+\]/.test(raw.trim())) continue; // [_TT_xx] bisa nempel ke token lain

    // API baru: offsets {from,to} dalam milidetik (fallback: tok.start/end lama)
    const tokStart = tok.offsets ? tok.offsets.from / 1000 : tok.start;
    const tokEnd = tok.offsets ? tok.offsets.to / 1000 : tok.end;
    if (tokStart == null || tokEnd == null) continue; // tanpa timing -> buang

    const startsNew = /^[\s▁]/.test(raw);
    const trimmed = raw.replace(/^▁/, '').trim();
    if (!trimmed) continue;

    const isPunct = /^[.,!?;:…%)\]]/.test(trimmed);
    if (startsNew && !isPunct) {
      pushWord(cur);
      cur = {text: trimmed, start: tokStart, end: tokEnd};
    } else if (cur) {
      cur.text += trimmed; // lanjutan sub-kata / tanda baca
      cur.end = tokEnd;
    } else {
      cur = {text: trimmed, start: tokStart, end: tokEnd};
    }
  }
  // JANGAN flush di akhir segmen — kata bisa lanjut ke segmen berikutnya
}
pushWord(cur);

const outFile = path.join('out/transcripts', `${base}${flags.language ? `-${flags.language}` : ''}.json`);
fs.writeFileSync(
  outFile,
  JSON.stringify({video: videoPath, model: flags.model, words}, null, 2)
);
console.log(`[transcribe] OK -> ${outFile} (${words.length} kata)`);
