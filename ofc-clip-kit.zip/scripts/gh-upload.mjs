#!/usr/bin/env node
/**
 * Upload file ke GitHub repo clip-sessions via Contents API.
 * Dipakai untuk upload klip SATU-SATU begitu selesai render
 * (tanpa menunggu semua klip selesai).
 *
 * Pemakaian:
 *   node scripts/gh-upload.mjs <localfile> <repo-path> ["commit msg"]
 *
 * Contoh:
 *   node scripts/gh-upload.mjs out/clips/clip-01.mp4 sesi-09-bobon-politik/clip-01-xxx.mp4
 */
import fs from 'node:fs';

const OWNER = 'kasyaira';
const REPO = 'clip-sessions';
// TOKEN TIDAK LAGI HARDCODE (sesi-10) — token hardcode pernah ter-publish ke
// repo publik via zip kit dan otomatis di-revoke GitHub secret scanning.
// Sekarang dibaca dari file eksternal di LUAR kit (tidak pernah ikut ke repo):
const TOKEN = fs.readFileSync('/home/z/my-project/work/.ghtoken', 'utf8').trim();
if (!TOKEN) { console.error('TOKEN kosong: isi /home/z/my-project/work/.ghtoken'); process.exit(1); }

const [, , localPath, repoPath, msgArg] = process.argv;
if (!localPath || !repoPath) {
  console.error('Pemakaian: node gh-upload.mjs <localfile> <repo-path> ["commit msg"]');
  process.exit(1);
}
if (!fs.existsSync(localPath)) {
  console.error('File tidak ada:', localPath);
  process.exit(1);
}

const API = `https://api.github.com/repos/${OWNER}/${REPO}/contents/${encodeURI(repoPath)}`;
const headers = {
  Authorization: `Bearer ${TOKEN}`,
  Accept: 'application/vnd.github+json',
  'X-GitHub-Api-Version': '2022-11-28',
  'User-Agent': 'clip-uploader',
};

const msg = msgArg || `upload: ${repoPath.split('/').pop()}`;

// cek apakah file sudah ada (butuh sha utk update)
const existing = await fetch(API, {headers, method: 'GET'});
const meta = existing.ok ? await existing.json() : null;

const content = fs.readFileSync(localPath).toString('base64');
const body = JSON.stringify({
  message: msg,
  content,
  sha: meta ? meta.sha : undefined,
});

console.log(`[gh] ${meta ? 'update' : 'create'} ${repoPath} (${(fs.statSync(localPath).size / 1024 / 1024).toFixed(1)} MB)...`);
const res = await fetch(API, {headers, method: 'PUT', body});
const j = await res.json();

if (!res.ok) {
  // file >~50MB -> Contents API 422 "too large to be processed".
  // Fallback: Git data API (blob -> tree -> commit -> update ref), file tetap utuh.
  if (res.status === 422 || res.status === 502) {
    console.log(`[gh] Contents API ${res.status} — pakai Git blob/tree/commit API...`);
    process.exit(await uploadViaGitApi(localPath, repoPath, msg, headers));
  }
  console.error(`[gh] GAGAL ${res.status}: ${JSON.stringify(j).slice(0, 400)}`);
  process.exit(1);
}
console.log(`[gh] OK -> ${j.content?.html_url || repoPath} (sha ${String(j.content?.sha).slice(0, 8)})`);

/** Upload file besar via Git data API (blobs sampai 100MB). Exit code 0 sukses. */
async function uploadViaGitApi(localPath, repoPath, msg, headers) {
  const api = (p) => `https://api.github.com/repos/${OWNER}/${REPO}/git/${p}`;
  const jf = async (u, opt) => {
    const r = await fetch(u, {headers, ...opt});
    const d = await r.json();
    if (!r.ok) throw new Error(`${r.status} ${u}: ${JSON.stringify(d).slice(0, 300)}`);
    return d;
  };
  // 1) HEAD commit main
  const head = await jf(`https://api.github.com/repos/${OWNER}/${REPO}/git/ref/heads/main`, {method: 'GET'});
  const commitSha = head.object.sha;
  const baseCommit = await jf(`https://api.github.com/repos/${OWNER}/${REPO}/git/commits/${commitSha}`, {method: 'GET'});
  // 2) blob
  const blob = await jf(api('blobs'), {
    method: 'POST',
    body: JSON.stringify({content: fs.readFileSync(localPath).toString('base64'), encoding: 'base64'}),
  });
  // 3) tree
  const tree = await jf(api('trees'), {
    method: 'POST',
    body: JSON.stringify({
      base_tree: baseCommit.tree.sha,
      tree: [{path: repoPath, mode: '100644', type: 'blob', sha: blob.sha}],
    }),
  });
  // 4) commit
  const commit = await jf(api('commits'), {
    method: 'POST',
    body: JSON.stringify({message: msg, tree: tree.sha, parents: [commitSha]}),
  });
  // 5) update ref
  await jf(`https://api.github.com/repos/${OWNER}/${REPO}/git/refs/heads/main`, {
    method: 'PATCH',
    body: JSON.stringify({sha: commit.sha, force: false}),
  });
  console.log(`[gh] OK (git api) -> ${repoPath} (commit ${String(commit.sha).slice(0, 8)})`);
  return 0;
}
