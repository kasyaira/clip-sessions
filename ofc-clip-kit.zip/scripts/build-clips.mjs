#!/usr/bin/env node
/**
 * ============================================================
 *  STEP 2 — BUILD DATA KLIP
 * ============================================================
 *  render-inputs/clips.json  +  out/transcripts/<video>.json
 *        -> out/data/<clip-id>.json
 *
 *  Tiap file data berisi: id, video, clipStart, clipEnd,
 *  dan timing kata yang SUDAH digeser relatif terhadap awal klip
 *  (plus padding lead/tail dari src/project.json).
 *
 *  Pemakaian:
 *    npm run build-data
 * ============================================================
 */
import fs from 'node:fs';
import path from 'node:path';

const SHEET_FILE = 'render-inputs/clips.json';

if (!fs.existsSync(SHEET_FILE)) {
  console.error(`[build-data] ${SHEET_FILE} belum ada.`);
  console.error('Salin dulu: cp render-inputs/clips.example.json render-inputs/clips.json');
  console.error('Lalu isi rentang potongan sesuai bahan (disarankan 40-180 detik per klip).');
  process.exit(1);
}

const sheet = JSON.parse(fs.readFileSync(SHEET_FILE, 'utf8'));
const project = JSON.parse(fs.readFileSync('src/project.json', 'utf8'));
const TIMING = {lead: project.lead, tail: project.tail};

const sourcePath = path.join('public', sheet.video);
if (!fs.existsSync(sourcePath)) {
  console.error(`[build-data] video tidak ditemukan: ${sourcePath}`);
  console.error('Taruh video mentah di public/input/ lalu sesuaikan field "video".');
  process.exit(1);
}

const base = path.basename(sheet.video, path.extname(sheet.video));
// sheet boleh menunjuk transkrip tertentu, mis. "raw-id.json" (bahasa Indonesia)
const transcriptFile = sheet.transcript
  ? path.join('out/transcripts', sheet.transcript)
  : path.join('out/transcripts', `${base}.json`);
if (!fs.existsSync(transcriptFile)) {
  console.error(`[build-data] transkrip tidak ditemukan: ${transcriptFile}`);
  console.error(`Jalankan dulu: npm run transcribe -- public/${sheet.video}`);
  process.exit(1);
}
const transcript = JSON.parse(fs.readFileSync(transcriptFile, 'utf8'));

fs.mkdirSync('out/data', {recursive: true});

const warnings = [];
const seenIds = new Set();
let count = 0;

for (const cut of sheet.clips) {
  const dur = cut.end - cut.start;
  if (!/^[a-zA-Z0-9._-]+$/.test(cut.id)) {
    warnings.push(`id "${cut.id}" mengandung karakter aneh — pakai huruf/angka/-/_ saja.`);
  }
  if (seenIds.has(cut.id)) {
    warnings.push(`id "${cut.id}" duplikat — file akan saling menimpa.`);
  }
  seenIds.add(cut.id);
  if (dur < 40) warnings.push(`${cut.id}: durasi ${dur.toFixed(1)}s < 40s (di bawah rekomendasi).`);
  if (dur > 180) warnings.push(`${cut.id}: durasi ${dur.toFixed(1)}s > 180s (di atas rekomendasi 3 menit).`);

  // ambil kata yang berada di dalam rentang potongan, geser relatif ke awal klip
  const words = transcript.words
    .filter((w) => w.end > cut.start + 0.01 && w.start < cut.end - 0.01)
    .map((w) => {
      const s = Math.max(w.start - cut.start, 0);
      const e = Math.min(w.end - cut.start, dur);
      return {
        text: w.text,
        start: Math.round((s + TIMING.lead) * 1000) / 1000,
        end: Math.round((e + TIMING.lead) * 1000) / 1000,
      };
    })
    .filter((w) => w.end - w.start > 0.015);

  if (words.length === 0) {
    warnings.push(`${cut.id}: tidak ada kata dari transkrip di rentang ${cut.start}-${cut.end}s (subtitle kosong).`);
  }

  const data = {
    id: cut.id,
    video: sheet.video,
    clipStart: cut.start,
    clipEnd: cut.end,
    words,
  };
  fs.writeFileSync(
    path.join('out/data', `${cut.id}.json`),
    JSON.stringify(data, null, 2)
  );
  console.log(`[build-data] OK ${cut.id}  ${dur.toFixed(1)}s  ${words.length} kata`);
  count++;
}

console.log(`[build-data] selesai: ${count} file di out/data/`);
if (warnings.length) {
  console.warn('\n[build-data] PERINGATAN:');
  for (const w of warnings) console.warn(`  - ${w}`);
}
