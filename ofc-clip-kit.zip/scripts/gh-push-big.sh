#!/usr/bin/env bash
# Upload file besar (>50MB, Contents/Blob API 422) via git plumbing:
# fetch blob-less -> hash-object -> read-tree -> update-index -> commit-tree -> push
# Pemakaian: bash scripts/gh-push-big.sh <localfile> <repo-path> "<commit msg>"
set -euo pipefail
FILE="${1:?file lokal}"; REPO_PATH="${2:?path di repo}"; MSG="${3:-upload}"
OWNER="kasyaira"; REPO="clip-sessions"
# TOKEN TIDAK LAGI HARDCODE — sesi-10: token hardcode pernah ikut ter-publish
# ke repo PUBLIK (ofc-clip-kit.zip) dan otomatis di-revoke GitHub secret
# scanning. Token sekarang dibaca dari file eksternal di LUAR kit:
#   cat /home/z/my-project/work/.ghtoken  (isi: PAT baru, satu baris)
TOKEN="$(cat /home/z/my-project/work/.ghtoken 2>/dev/null)"
[ -n "$TOKEN" ] || { echo "TOKEN kosong: isi /home/z/my-project/work/.ghtoken dulu"; exit 1; }
WORK=/home/z/my-project/work/gh-push

[ -f "$FILE" ] || { echo "file tidak ada: $FILE"; exit 1; }
FILE="$(readlink -f "$FILE")"
mkdir -p "$WORK"; cd "$WORK"
[ -d .git ] || { git init -q .; git remote add origin "https://${OWNER}:${TOKEN}@github.com/${OWNER}/${REPO}.git"; }
git fetch --depth 1 --filter=blob:none origin main 2>/dev/null
BLOB=$(git hash-object -w "$FILE")
git read-tree "origin/main^{tree}"
git update-index --add --cacheinfo "100644,${BLOB},${REPO_PATH}"
TREE=$(git write-tree)
COMMIT=$(git commit-tree "$TREE" -p origin/main -m "$MSG")
set +e
git push origin "$COMMIT:main" 2>&1 | tail -2
PUSH_OK=${PIPESTATUS[0]}
set -e
# §11 CARA-KERJA: push melakukan lazy-fetch SEMUA blob repo (±1.4GB)
# -> WAJIB hapus work dir setelah tiap push supaya tidak membengkak
#    (fetch ulang berikutnya hanya beberapa detik)
cd /home/z/my-project/work && rm -rf "$WORK"
if [ "$PUSH_OK" -eq 0 ]; then
  echo "OK (git push) -> ${REPO_PATH} (commit ${COMMIT:0:8})"
else
  echo "GAGAL push (exit $PUSH_OK) -> ${REPO_PATH}"
  exit "$PUSH_OK"
fi
