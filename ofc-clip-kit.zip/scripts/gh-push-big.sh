#!/usr/bin/env bash
# Upload file besar (>50MB, Contents/Blob API 422) via git plumbing:
# fetch blob-less -> hash-object -> read-tree -> update-index -> commit-tree -> push
# Pemakaian: bash scripts/gh-push-big.sh <localfile> <repo-path> "<commit msg>"
set -euo pipefail
FILE="${1:?file lokal}"; REPO_PATH="${2:?path di repo}"; MSG="${3:-upload}"
OWNER="kasyaira"; REPO="clip-sessions"
TOKEN="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"
WORK=/home/z/my-project/work/gh-push

[ -f "$FILE" ] || { echo "file tidak ada: $FILE"; exit 1; }
FILE="$(readlink -f "$FILE")"
mkdir -p "$WORK"; cd "$WORK"
[ -d .git ] || { git init -q .; git remote add origin "https://${OWNER}:${TOKEN}@github.com/${OWNER}/${REPO}.git"; }
git fetch --depth 1 --filter=blob:none origin main 2>/dev/null
BLOB=$(git hash-object -w "$FILE")
git read-tree "origin/main^{tree}"
git update-index --add --cacheinfo "100644,${BLOB},${REPO_PATH}"
TREE=$(git write-tree)
COMMIT=$(git commit-tree "$TREE" -p origin/main -m "$MSG")
git push origin "$COMMIT:main" 2>&1 | tail -2
echo "OK (git push) -> ${REPO_PATH} (commit ${COMMIT:0:8})"
