#!/usr/bin/env node
/**
 * ============================================================
 *  TRANSCRIBE PER-BAGIAN (video panjang > 10 menit / limit tool call)
 * ============================================================
 *  Whisper small di sandbox 2-core jalan ~0.9x realtime — video 50+
 *  menit TIDAK muat ditranskrip dalam satu panggilan tool (limit ±10
 *  menit). Script ini (lihat CARA-KERJA.md §4):
 *
 *    1. Potong WAV sumber jadi bagian <part> detik dengan <overlap>
 *       detik overlap ke bagian berikutnya.
 *    2. Transkrip tiap bagian (whisper.cpp langsung, token-level).
 *       IDEMPOTEN: bagian yang sudah punya JSON di-skip — aman
 *       dipanggil ulang sampai semua bagian selesai.
 *    3. --merge : gabungkan semua bagian jadi satu transkrip
 *       word-level. Titik sambung diambil <split-in> detik masuk ke
 *       dalam overlap (bukan pas di batas mentah) supaya kata yang
 *       terpotong di ujung bagian tidak hilang/dobel.
 *
 *  Pemakaian:
 *    node scripts/transcribe-parts.mjs --wav out/tmp/raw.16k.wav \
 *         --language id --duration 3180
 *    node scripts/transcribe-parts.mjs --merge        # setelah semua bagian selesai
 *    node scripts/transcribe-parts.mjs --status       # lihat progres bagian
 * ============================================================
 */
import fs from 'node:fs';
import path from 'node:path';
import {execSync} from 'node:child_process';

const args = process.argv.slice(2);
const flags = {
  wav: 'out/tmp/raw.16k.wav',
  duration: null,
  part: 420,
  overlap: 6,
  splitIn: 3,
  language: 'id',
  model: 'small',
  maxSeconds: 460, // budget detik per invokasi (sisakan buffer dr limit 10 menit)
  merge: false,
  status: false,
};
for (let i = 0; i < args.length; i++) {
  const a = args[i];
  if (a === '--merge') flags.merge = true;
  else if (a === '--status') flags.status = true;
  else if (a === '--wav') flags.wav = args[++i];
  else if (a === '--duration') flags.duration = Number(args[++i]);
  else if (a === '--part') flags.part = Number(args[++i]);
  else if (a === '--overlap') flags.overlap = Number(args[++i]);
  else if (a === '--split-in') flags.splitIn = Number(args[++i]);
  else if (a === '--language') flags.language = args[++i];
  else if (a === '--model') flags.model = args[++i];
  else if (a === '--max-seconds') flags.maxSeconds = Number(args[++i]);
}

const PARTS_DIR = 'out/tmp/parts';
fs.mkdirSync(PARTS_DIR, {recursive: true});

// durasi audio dari ffprobe kalau tidak dikasih
if (!flags.duration) {
  console.log('[parts] deteksi durasi via ffprobe...');
  const out = execSync(
    `ffprobe -v error -show_entries format=duration -of csv=p=0 "${flags.wav}"`
  ).toString().trim();
  flags.duration = Math.ceil(Number(out));
}
const D = flags.duration;
const parts = [];
for (let start = 0; start < D; start += flags.part) {
  parts.push({index: parts.length, start, end: Math.min(start + flags.part + flags.overlap, D)});
}
const pad = (n) => String(n).padStart(3, '0');
const partJson = (i) => path.join(PARTS_DIR, `part-${pad(i)}.json`);

if (flags.status) {
  console.log(`[parts] total ${parts.length} bagian (${flags.part}s + ${flags.overlap}s overlap), durasi ${D}s`);
  for (const p of parts) {
    const done = fs.existsSync(partJson(p.index));
    console.log(`  part-${pad(p.index)}  ${p.start}-${p.end}s  ${done ? 'SELESAI' : 'pending'}`);
  }
  process.exit(0);
}

// ----------------------------------------------------------------
// MODE TRANSCRIBE (loop bagian pending, hormati budget waktu)
// ----------------------------------------------------------------
if (!flags.merge) {
  const T0 = Date.now();
  let processed = 0;
  for (const p of parts) {
    if (fs.existsSync(partJson(p.index))) continue;
    const elapsed = (Date.now() - T0) / 1000;
    const est = (p.end - p.start) * 0.95; // estimasi ~0.9-0.95x realtime + buffer
    if (elapsed + est > flags.maxSeconds) {
      console.log(`[parts] budget ${flags.maxSeconds}s tercapai (elapsed ${elapsed.toFixed(0)}s, est berikut ${est.toFixed(0)}s) — panggil lagi script ini untuk lanjut.`);
      process.exit(2);
    }

    const wavPart = path.join(PARTS_DIR, `part-${pad(p.index)}.wav`);
    console.log(`[parts] potong part-${pad(p.index)} (${p.start}-${p.end}s)...`);
    execSync(
      `ffmpeg -y -v error -ss ${p.start} -t ${p.end - p.start} -i "${flags.wav}" -c copy "${wavPart}"`
    );

    console.log(`[parts] transkrip part-${pad(p.index)} (${p.end - p.start}s audio, est ${est.toFixed(0)}s)...`);
    const t1 = Date.now();
    execSync(
      `./whisper.cpp/main -m whisper.cpp/ggml-${flags.model}.bin -l ${flags.language} ` +
      `--max-len 1 -oj -of "${path.join(PARTS_DIR, `part-${pad(p.index)}`)}" -f "${wavPart}"`,
      {stdio: ['ignore', 'ignore', 'ignore']}
    );
    const took = (Date.now() - t1) / 1000;
    if (!fs.existsSync(partJson(p.index))) {
      console.error(`[parts] GAGAL: ${partJson(p.index)} tidak tercipta`);
      process.exit(1);
    }
    console.log(`[parts] OK part-${pad(p.index)} (${took.toFixed(0)}s, rasio ${(took / (p.end - p.start)).toFixed(2)}x)`);
    processed++;
    // buang wav bagian yang sudah selesai (hemat disk, json-nya tetap)
    fs.rmSync(wavPart, {force: true});
  }
  console.log(`[parts] semua bagian selesai (${processed} diproses invokasi ini). Lanjut: node scripts/transcribe-parts.mjs --merge`);
  process.exit(0);
}

// ----------------------------------------------------------------
// MODE MERGE (gabung bagian -> transkrip word-level utuh)
// ----------------------------------------------------------------
console.log(`[merge] gabung ${parts.length} bagian, split +${flags.splitIn}s ke dalam overlap ${flags.overlap}s...`);

// token -> kata (logika sama dengan transcribe.mjs)
const tokensToWords = (tokens, offsetSec) => {
  const words = [];
  let cur = null;
  const push = () => {
    if (cur && cur.text.trim()) words.push(cur);
  };
  for (const tok of tokens) {
    const raw = tok.text ?? '';
    if (!raw.trim()) continue;
    if (/^<\|.*\|>$/.test(raw.trim())) continue;
    if (/^\[_\w+\]$/.test(raw.trim())) continue;
    if (/\[_TT_\d+\]/.test(raw.trim())) continue;
    const s = tok.offsets.from / 1000 + offsetSec;
    const e = tok.offsets.to / 1000 + offsetSec;
    const startsNew = /^[\s▁]/.test(raw);
    const trimmed = raw.replace(/^▁/, '').trim();
    if (!trimmed) continue;
    const isPunct = /^[.,!?;:…%)\]]/.test(trimmed);
    if (startsNew && !isPunct) {
      push();
      cur = {text: trimmed, start: s, end: e};
    } else if (cur) {
      cur.text += trimmed;
      cur.end = e;
    } else {
      cur = {text: trimmed, start: s, end: e};
    }
  }
  push();
  return words;
};

const allWords = [];
let gaps = 0;
for (let i = 0; i < parts.length; i++) {
  const p = parts[i];
  if (!fs.existsSync(partJson(i))) {
    console.error(`[merge] ${partJson(i)} belum ada — jalankan mode transcribe sampai semua bagian selesai.`);
    process.exit(1);
  }
  const raw = JSON.parse(fs.readFileSync(partJson(i), 'utf8'));
  // whisper -oj: { transcription: [ {offsets, text}, ... ] } dgn --max-len 1 = per-token
  const tokens = raw.transcription.map((seg) => ({
    text: seg.text,
    offsets: seg.offsets,
  }));
  const words = tokensToWords(tokens, p.start);

  if (i === 0) {
    allWords.push(...words);
  } else {
    // split point: masuk flags.splitIn detik ke area overlap bagian sebelumnya
    const split = p.start + flags.splitIn;
    // 1) buang kata EKOR dari gabungan (bagian sebelumnya) yang mulainya
    //    sudah lewat split — dia dobel/di luar wilayah bagian sebelumnya
    let droppedTail = 0;
    while (allWords.length && allWords[allWords.length - 1].start >= split) {
      allWords.pop();
      droppedTail++;
    }
    // 2) buang kata dari bagian ini yang mulainya sebelum split (dobel dgn ekor)
    const kept = words.filter((w) => w.start >= split);
    const dropped = words.length - kept.length;
    // cek gap: kata terakhir gabungan vs kata pertama yang disimpan
    const prev = allWords[allWords.length - 1];
    if (prev && kept[0] && kept[0].start - prev.end > 2.5) {
      console.warn(`[merge] WARNING gap ${ (kept[0].start - prev.end).toFixed(2)}s di sambungan part-${pad(i - 1)}/part-${pad(i)}`);
      gaps++;
    }
    console.log(`  part-${pad(i)}: ${words.length} kata, ${dropped} kepala + ${droppedTail} ekor dibuang`);
    allWords.push(...kept);
  }
}

// rapikan timestamp
for (const w of allWords) {
  w.start = Math.round(w.start * 1000) / 1000;
  w.end = Math.round(w.end * 1000) / 1000;
}
// validasi monoton
for (let i = 1; i < allWords.length; i++) {
  if (allWords[i].start < allWords[i - 1].start - 0.01) {
    console.warn(`[merge] WARNING urutan mundur di kata ${i}: "${allWords[i].text}"`);
  }
}

const outFile = 'out/transcripts/raw-parts.json';
fs.writeFileSync(outFile, JSON.stringify({video: 'public/input/raw.mp4', model: flags.model, words: allWords}, null, 2));
console.log(`[merge] OK -> ${outFile} (${allWords.length} kata, ${gaps} gap)`);
if (gaps > 0) {
  console.warn('[merge] ada gap — pertimbangkan --split-in lebih besar (mis. 4-5) dan merge ulang.');
}
