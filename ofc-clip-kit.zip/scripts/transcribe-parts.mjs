#!/usr/bin/env node
/**
 * ============================================================
 *  TRANSCRIBE PER-BAGIAN (video panjang > 10 menit whisper/call)
 *  Strategi dari CARA-KERJA.md §4 — TERBUKTI JALAN di sesi lalu:
 *    1. "init"      : ekstrak wav penuh + potong bagian (overlap)
 *    2. "part N"    : transkrip bagian N saja (idempoten, cache file)
 *    3. "merge"     : gabung semua bagian -> out/transcripts/raw.json
 *    4. "calibrate" : ukur kecepatan whisper dgn potongan 120s
 *                     -> tentukan partLen yang aman (< 8 menit proses)
 *
 *  Merge: split-point diambil +3s ke DALAM area overlap 6s,
 *  kata yang terpotong di ujung bagian otomatis utuh di bagian
 *  tetangga (ada di kedua bagian, di-drop yang dobel).
 *  Validasi: monotonic + gap antar kata <= 2.5s di titik sambung.
 *
 *  Pemakaian:
 *    node scripts/transcribe-parts.mjs calibrate
 *    node scripts/transcribe-parts.mjs init [--part-len 420] [--overlap 6]
 *    node scripts/transcribe-parts.mjs part 0
 *    node scripts/transcribe-parts.mjs merge
 */
import fs from 'node:fs';
import path from 'node:path';
import {execSync} from 'node:child_process';
import whisperSdk from '@remotion/install-whisper-cpp';

const WHISPER_CPP_VERSION = '1.7.3';
const WHISPER_DIR = 'whisper.cpp';
const {installWhisperCpp, downloadWhisperModel, transcribe} = whisperSdk;

const VIDEO = 'public/input/raw.mp4';
const TMP = 'out/tmp/parts';
const FULL_WAV = path.join(TMP, 'raw-full.16k.wav');
const META = path.join(TMP, 'parts-meta.json');
const OUT_TRANSCRIPT = 'out/transcripts/raw.json';
const MODEL = process.env.WHISPER_MODEL || 'small';
const LANG = 'id'; // video podcast Indonesia

const args = process.argv.slice(2);
const cmd = args[0] ?? 'help';
const getOpt = (name, dflt) => {
  const i = args.indexOf(name);
  return i >= 0 ? Number(args[i + 1]) : dflt;
};

const sh = (c) => execSync(c, {stdio: 'inherit'});

async function ensureWhisper() {
  await installWhisperCpp({version: WHISPER_CPP_VERSION, to: WHISPER_DIR, printOutput: true});
  await downloadWhisperModel({model: MODEL, folder: WHISPER_DIR, printOutput: true});
}

/** gabung token whisper -> kata (logika sama dgn transcribe.mjs) */
const tokensToWords = (transcription) => {
  const words = [];
  const pushWord = (w) => {
    if (w && w.text.trim()) {
      words.push({
        text: w.text,
        start: Math.round(w.start * 1000) / 1000,
        end: Math.round(w.end * 1000) / 1000,
      });
    }
  };
  let cur = null;
  for (const segment of transcription) {
    for (const tok of segment.tokens ?? []) {
      const raw = tok.text ?? '';
      if (!raw.trim()) continue;
      if (/^<\|.*\|>$/.test(raw.trim())) continue;
      if (/^\[_\w+\]$/.test(raw.trim())) continue;
      if (/\[_TT_\d+\]/.test(raw.trim())) continue;
      const tokStart = tok.offsets ? tok.offsets.from / 1000 : tok.start;
      const tokEnd = tok.offsets ? tok.offsets.to / 1000 : tok.end;
      if (tokStart == null || tokEnd == null) continue;
      const startsNew = /^[\s▁]/.test(raw);
      const trimmed = raw.replace(/^▁/, '').trim();
      if (!trimmed) continue;
      const isPunct = /^[.,!?;:…%)\]]/.test(trimmed);
      if (startsNew && !isPunct) {
        pushWord(cur);
        cur = {text: trimmed, start: tokStart, end: tokEnd};
      } else if (cur) {
        cur.text += trimmed;
        cur.end = tokEnd;
      } else {
        cur = {text: trimmed, start: tokStart, end: tokEnd};
      }
    }
  }
  pushWord(cur);
  return words;
};

async function runWhisper(wavPath) {
  const raw = await transcribe({
    inputPath: path.resolve(wavPath),
    whisperPath: WHISPER_DIR,
    whisperCppVersion: WHISPER_CPP_VERSION,
    model: MODEL,
    language: LANG,
    printOutput: false,
    tokenLevelTimestamps: true,
  });
  return tokensToWords(raw.transcription);
}

const wavDur = (f) =>
  Number(execSync(`ffprobe -v error -show_entries format=duration -of csv=p=0 "${f}"`).toString().trim());

// ---------------- commands ----------------

if (cmd === 'calibrate') {
  fs.mkdirSync(TMP, {recursive: true});
  const cut = path.join(TMP, 'calib-120s.wav');
  if (!fs.existsSync(cut)) {
    console.log('[calib] ekstrak potongan 120s pertama...');
    execSync(`ffmpeg -y -i "${VIDEO}" -vn -acodec pcm_s16le -ar 16000 -ac 1 -t 120 "${cut}"`, {stdio: 'ignore'});
  }
  await ensureWhisper();
  console.log('[calib] transkrip 120s (model ' + MODEL + ')...');
  const t0 = Date.now();
  await runWhisper(cut);
  const dt = (Date.now() - t0) / 1000;
  const speed = dt / 120; // detik proses per detik audio
  console.log(`[calib] 120s audio -> ${dt.toFixed(0)}s proses = ${speed.toFixed(2)}x realtime`);
  const safeLen = Math.floor((8 * 60) / Math.max(speed, 0.01)); // target < 8 menit
  console.log(`[calib] saran --part-len: ${Math.min(safeLen, 460)} (proses ~8 menit/bagian)`);
  process.exit(0);
}

if (cmd === 'init') {
  const partLen = getOpt('--part-len', 420);
  const overlap = getOpt('--overlap', 6);
  fs.mkdirSync(TMP, {recursive: true});
  console.log('[init] ekstrak wav 16kHz mono penuh...');
  execSync(`ffmpeg -y -i "${VIDEO}" -vn -acodec pcm_s16le -ar 16000 -ac 1 "${FULL_WAV}"`, {stdio: 'ignore'});
  const dur = wavDur(FULL_WAV);
  const step = partLen - overlap;
  const parts = [];
  for (let s = 0; s < dur; s += step) {
    const len = Math.min(partLen, dur - s);
    parts.push({start: Number(s.toFixed(3)), len: Number(len.toFixed(3))});
    if (len < partLen) break; // bagian terakhir
  }
  for (let i = 0; i < parts.length; i++) {
    const f = path.join(TMP, `part-${String(i).padStart(2, '0')}.wav`);
    if (!fs.existsSync(f)) {
      execSync(`ffmpeg -y -ss ${parts[i].start} -t ${parts[i].len} -i "${FULL_WAV}" -acodec copy "${f}"`, {stdio: 'ignore'});
    }
  }
  fs.writeFileSync(META, JSON.stringify({partLen, overlap, dur, parts}, null, 2));
  console.log(`[init] durasi ${dur.toFixed(1)}s -> ${parts.length} bagian (partLen=${partLen}, overlap=${overlap})`);
  for (let i = 0; i < parts.length; i++) {
    const done = fs.existsSync(path.join(TMP, `part-${String(i).padStart(2, '0')}.words.json`));
    console.log(`  bagian ${i}: ${parts[i].start}s +${parts[i].len}s ${done ? '[SELESAI]' : ''}`);
  }
  process.exit(0);
}

if (cmd === 'part') {
  const idx = Number(args[1]);
  if (!fs.existsSync(META)) {
    console.error('[part] jalankan "init" dulu'); process.exit(1);
  }
  const meta = JSON.parse(fs.readFileSync(META, 'utf8'));
  const wavPath = path.join(TMP, `part-${String(idx).padStart(2, '0')}.wav`);
  const outPath = wavPath.replace('.wav', '.words.json');
  if (fs.existsSync(outPath)) {
    const w = JSON.parse(fs.readFileSync(outPath, 'utf8'));
    console.log(`[part ${idx}] sudah ada (${w.length} kata) — skip`);
    process.exit(0);
  }
  await ensureWhisper();
  const t0 = Date.now();
  const words = await runWhisper(wavPath); // waktu LOKAL bagian
  fs.writeFileSync(outPath, JSON.stringify(words));
  console.log(`[part ${idx}] OK: ${words.length} kata dalam ${((Date.now() - t0) / 1000).toFixed(0)}s -> ${path.basename(outPath)}`);
  process.exit(0);
}

if (cmd === 'merge') {
  if (!fs.existsSync(META)) {
    console.error('[merge] jalankan "init" dulu'); process.exit(1);
  }
  const meta = JSON.parse(fs.readFileSync(META, 'utf8'));
  const {overlap, parts} = meta;
  const n = parts.length;
  const all = [];
  const report = [];
  for (let i = 0; i < n; i++) {
    const p = path.join(TMP, `part-${String(i).padStart(2, '0')}.words.json`);
    if (!fs.existsSync(p)) {
      console.error(`[merge] bagian ${i} belum ditranskrip: ${p}`); process.exit(1);
    }
    const local = JSON.parse(fs.readFileSync(p, 'utf8'));
    const gStart = parts[i].start;
    // Batas kiri/kanan dalam waktu LOKAL bagian (aturan drop-dobel):
    //   split dgn bagian SEBELUMNYA ada di lokal overlap/2 (mis. 3s)
    //   split dgn bagian SESUDAHNYA ada di lokal partLen - overlap/2 (mis. 417s)
    // Jadi bagian menyimpan kata di [overlap/2, partLen-overlap/2) lokal,
    // kecuali bagian pertama (dari 0) & terakhir (sampai habis).
    const partLen = meta.partLen;
    const leftCut = i === 0 ? -1 : overlap / 2;
    const rightCut = i === n - 1 ? Infinity : partLen - overlap / 2;
    const kept = local.filter((w) => w.start >= leftCut && w.start < rightCut);
    report.push({part: i, local: local.length, kept: kept.length});
    for (const w of kept) {
      all.push({
        text: w.text,
        start: Math.round((gStart + w.start) * 1000) / 1000,
        end: Math.round((gStart + w.end) * 1000) / 1000,
      });
    }
  }
  // validasi: monotonic + tidak ada gap aneh di titik sambung
  let mono = true;
  let maxBackJump = 0;
  for (let i = 1; i < all.length; i++) {
    if (all[i].start < all[i - 1].start - 0.01) {
      mono = false;
      maxBackJump = Math.max(maxBackJump, all[i - 1].start - all[i].start);
    }
  }
  fs.mkdirSync('out/transcripts', {recursive: true});
  fs.writeFileSync(OUT_TRANSCRIPT, JSON.stringify({video: 'input/raw.mp4', model: MODEL, words: all}, null, 2));
  console.log('[merge] laporan per bagian:', JSON.stringify(report));
  console.log(`[merge] total ${all.length} kata, mono=${mono}, maxBackJump=${maxBackJump.toFixed(2)}s`);
  console.log(`[merge] -> ${OUT_TRANSCRIPT}`);
  if (!mono) {
    console.error('[merge] !! ada kata tidak monotonik — cek titik sambung (lihat CARA-KERJA §4.5)');
    process.exit(1);
  }
  process.exit(0);
}

if (cmd === 'status') {
  if (!fs.existsSync(META)) { console.log('[status] belum init'); process.exit(0); }
  const meta = JSON.parse(fs.readFileSync(META, 'utf8'));
  meta.parts.forEach((p, i) => {
    const done = fs.existsSync(path.join(TMP, `part-${String(i).padStart(2, '0')}.words.json`));
    console.log(`bagian ${i}/${meta.parts.length - 1}: ${p.start}s +${p.len}s ${done ? '[SELESAI]' : '[PENDING]'}`);
  });
  process.exit(0);
}

console.log('Pemakaian: calibrate | init [--part-len N] [--overlap N] | part N | merge | status');
