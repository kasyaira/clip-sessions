#!/usr/bin/env node
/**
 * ============================================================
 *  TRANSCRIBE PER-BAGIAN (video panjang > ~8 menit)
 * ============================================================
 *  Whisper small di sandbox 2-core jalan < realtime, sedangkan
 *  satu tool call dibatasi ±10 menit. Maka video panjang WAJIB
 *  dipecah per-bagian (lihat CARA-KERJA.md §4).
 *
 *  Pemakaian:
 *    node scripts/transcribe-parts.mjs calib            # transkrip slice 120s, ukur kecepatan
 *    node scripts/transcribe-parts.mjs part 1 0 396     # bagian 1: mulai 0s, durasi 396s
 *    node scripts/transcribe-parts.mjs merge raw-id 393 # gabung bagian, split-point 393s
 *
 *  Output:
 *    out/transcripts/parts/raw.part<N>.json  (kata, waktu ABSOLUT video)
 *    out/transcripts/<name>.json             (hasil merge, format standar kit)
 * ============================================================
 */
import fs from 'node:fs';
import path from 'node:path';
import {execSync} from 'node:child_process';
import whisperSdk from '@remotion/install-whisper-cpp';

const WHISPER_CPP_VERSION = '1.7.3';
const WHISPER_DIR = 'whisper.cpp';
const {transcribe} = whisperSdk;

const LANGUAGE = 'id';
const MODEL = 'small';
const FULL_WAV = 'out/tmp/raw.16k.wav';
const PART_DIR = 'out/transcripts/parts';

const mode = process.argv[2] ?? 'calib';

// ---------- token -> kata (logika sama dgn transcribe.mjs) ----------
function tokensToWords(transcription) {
  const words = [];
  const pushWord = (w) => {
    if (w && w.text.trim()) {
      words.push({
        text: w.text,
        start: Math.round(w.start * 1000) / 1000,
        end: Math.round(w.end * 1000) / 1000,
      });
    }
  };
  let cur = null;
  for (const segment of transcription) {
    for (const tok of segment.tokens ?? []) {
      const raw = tok.text ?? '';
      if (!raw.trim()) continue;
      if (/^<\|.*\|>$/.test(raw.trim())) continue;
      if (/^\[_\w+\]$/.test(raw.trim())) continue;
      if (/\[_TT_\d+\]/.test(raw.trim())) continue;
      const tokStart = tok.offsets ? tok.offsets.from / 1000 : tok.start;
      const tokEnd = tok.offsets ? tok.offsets.to / 1000 : tok.end;
      if (tokStart == null || tokEnd == null) continue;
      const startsNew = /^[\s▁]/.test(raw);
      const trimmed = raw.replace(/^▁/, '').trim();
      if (!trimmed) continue;
      const isPunct = /^[.,!?;:…%)\]]/.test(trimmed);
      if (startsNew && !isPunct) {
        pushWord(cur);
        cur = {text: trimmed, start: tokStart, end: tokEnd};
      } else if (cur) {
        cur.text += trimmed;
        cur.end = tokEnd;
      } else {
        cur = {text: trimmed, start: tokStart, end: tokEnd};
      }
    }
  }
  pushWord(cur);
  return words;
}

async function runWhisper(wavPath, cacheTag) {
  fs.mkdirSync('out/tmp', {recursive: true});
  const cachePath = path.join('out/tmp', `${cacheTag}.whisper-cache.json`);
  if (fs.existsSync(cachePath)) {
    console.log(`[parts] pakai cache: ${cachePath}`);
    return JSON.parse(fs.readFileSync(cachePath, 'utf8'));
  }
  const rawJson = await transcribe({
    inputPath: path.resolve(wavPath),
    whisperPath: WHISPER_DIR,
    whisperCppVersion: WHISPER_CPP_VERSION,
    model: MODEL,
    language: LANGUAGE,
    printOutput: false,
    tokenLevelTimestamps: true,
  });
  fs.writeFileSync(cachePath, JSON.stringify(rawJson));
  return rawJson;
}

// ============================================================
// MODE: calib — kalibrasi kecepatan whisper (slice 120s)
// ============================================================
if (mode === 'calib') {
  const wav = 'out/tmp/calib120.wav';
  if (!fs.existsSync(wav)) {
    execSync(`ffmpeg -y -v error -i ${FULL_WAV} -t 120 -acodec copy ${wav}`);
  }
  const t0 = Date.now();
  const raw = await runWhisper(wav, 'calib120');
  const el = (Date.now() - t0) / 1000;
  const words = tokensToWords(raw.transcription);
  console.log(`[calib] 120s audio -> ${el.toFixed(1)}s wall (${(120 / el).toFixed(2)}x realtime)`);
  console.log(`[calib] ${words.length} kata; contoh: ${words.slice(0, 8).map((w) => w.text).join(' ')}`);
  console.log(`[calib] rekomendasi durasi bagian (utk budget 420s wall): ${Math.floor((120 / el) * 420)}s`);
  process.exit(0);
}

// ============================================================
// MODE: part N START DUR — potong + transkrip satu bagian
// ============================================================
if (mode === 'part') {
  const N = process.argv[3];
  const start = parseFloat(process.argv[4]);
  const dur = parseFloat(process.argv[5]);
  const wav = `out/tmp/raw.part${N}.wav`;
  fs.mkdirSync(PART_DIR, {recursive: true});
  if (!fs.existsSync(wav)) {
    console.log(`[part${N}] potong audio ${start}s +${dur}s...`);
    execSync(`ffmpeg -y -v error -i ${FULL_WAV} -ss ${start} -t ${dur} -acodec copy ${wav}`);
  }
  const t0 = Date.now();
  const raw = await runWhisper(wav, `raw.part${N}`);
  const words = tokensToWords(raw.transcription).map((w) => ({
    text: w.text,
    start: Math.round((w.start + start) * 1000) / 1000,
    end: Math.round((w.end + start) * 1000) / 1000,
  }));
  const out = path.join(PART_DIR, `raw.part${N}.json`);
  fs.writeFileSync(out, JSON.stringify({part: N, start, dur, words}, null, 2));
  const el = (Date.now() - t0) / 1000;
  console.log(
    `[part${N}] OK ${words.length} kata (absolut ${start}-${start + dur}s) dalam ${el.toFixed(0)}s -> ${out}`
  );
  console.log(`[part${N}] awal: ${words.slice(0, 6).map((w) => w.text).join(' ')}`);
  console.log(`[part${N}] akhir: ${words.slice(-6).map((w) => w.text).join(' ')}`);
  process.exit(0);
}

// ============================================================
// MODE: merge NAME SPLIT1 SPLIT2 ... — gabung bagian berturut
//  splitN = detik absolut batas bagian N -> N+1 (di tengah overlap)
// ============================================================
if (mode === 'merge') {
  const name = process.argv[3];
  const splits = process.argv.slice(4).map(Number);
  const partFiles = fs
    .readdirSync(PART_DIR)
    .filter((f) => /^raw\.part\d+\.json$/.test(f))
    .sort((a, b) => parseInt(a.match(/\d+/)[0]) - parseInt(b.match(/\d+/)[0]));
  if (partFiles.length === 0) {
    console.error('[merge] tidak ada file bagian di ' + PART_DIR);
    process.exit(1);
  }
  if (splits.length !== partFiles.length - 1) {
    console.error(`[merge] butuh ${partFiles.length - 1} split-point, dapat ${splits.length}`);
    process.exit(1);
  }
  console.log(`[merge] ${partFiles.length} bagian, split: ${splits.join(', ')}`);
  const merged = [];
  partFiles.forEach((f, i) => {
    const part = JSON.parse(fs.readFileSync(path.join(PART_DIR, f), 'utf8'));
    const lo = i === 0 ? -Infinity : splits[i - 1];
    const hi = i === partFiles.length - 1 ? Infinity : splits[i];
    const keep = part.words.filter((w) => w.start >= lo - 0.001 && w.start < hi - 0.001);
    const drop = part.words.length - keep.length;
    console.log(`  ${f}: ${part.words.length} kata -> keep ${keep.length} (drop ${drop})`);
    merged.push(...keep);
  });
  // ---- post-processing 1: run kata dengan start menurun = artefak whisper ----
  // whisper.cpp (max-len 1 + DTW) kadang meng-emit satu kalimat dengan timestamp
  // TERBALIK / ter-halusinasi dari konteks sebelumnya (nilai dipakai ulang).
  // Kata-kata itu tidak bisa diselamatkan dengan dibalik urutan saja —
  // solusinya: pertahankan URUTAN TEKS sesuai emit, lalu re-time seluruh blok
  // proporsional di antara kata sehat sebelum/sesudahnya.
  for (let i = 1; i < merged.length; ) {
    if (merged[i].start < merged[i - 1].start - 0.001) {
      // cari ujung run menurun
      let j = i;
      while (
        j + 1 < merged.length &&
        merged[j + 1].start < merged[j].start - 0.001
      ) {
        j++;
      }
      const a = i - 1; // kata pertama run (start-nya naik normal, end-nya sering < start)
      const b = j; // kata terakhir run
      const prevGood = merged[a - 1];
      const nextGood = merged[b + 1];
      const runMin = Math.min(...merged.slice(a, b + 1).map((w) => w.start));
      const runMax = Math.max(...merged.slice(a, b + 1).map((w) => w.end));
      let t0 = prevGood ? prevGood.end : runMin;
      let t1 = nextGood ? nextGood.start : runMax;
      if (t1 - t0 < 0.1 * (b - a + 1)) {
        // tetangga tidak memberi ruang cukup -> pakai rentang run sendiri
        t0 = runMin;
        t1 = runMax > t0 ? runMax : t0 + 0.3 * (b - a + 1);
      }
      const n = b - a + 1;
      const step = (t1 - t0) / n;
      for (let k = 0; k < n; k++) {
        merged[a + k] = {
          text: merged[a + k].text,
          start: Math.round((t0 + k * step) * 1000) / 1000,
          end: Math.round((t0 + (k + 1) * step - 0.012) * 1000) / 1000,
        };
      }
      console.log(
        `  * re-time blok korup ${n} kata ke rentang ${t0.toFixed(1)}-${t1.toFixed(1)}s`
      );
      i = b + 1;
    } else {
      i++;
    }
  }

  // ---- post-processing 2: kata zero-duration (start == end) ----
  // beri durasi minimal supaya tidak terbuang oleh filter build-data
  let fixedDur = 0;
  for (let i = 0; i < merged.length; i++) {
    const w = merged[i];
    if (w.end - w.start < 0.02) {
      const next = merged[i + 1];
      const cap = next ? Math.max(next.start, w.start + 0.02) : w.start + 0.15;
      w.end = Math.round(Math.min(w.start + 0.15, Math.max(cap, w.start + 0.02)) * 1000) / 1000;
      fixedDur++;
    }
  }
  if (fixedDur) console.log(`  * perbaiki ${fixedDur} kata zero-duration`);

  // ---- validasi akhir ----
  let problems = 0;
  for (let i = 1; i < merged.length; i++) {
    const prev = merged[i - 1];
    const cur = merged[i];
    if (cur.start < prev.end - 0.05) {
      console.warn(`  ! tumpang tindih @${cur.start}s: "${prev.text}" (${prev.start}-${prev.end}) vs "${cur.text}" (${cur.start}-${cur.end})`);
      problems++;
    }
    if (cur.start < prev.start - 0.001) {
      console.warn(`  ! urutan mundur @${cur.start}s: "${prev.text}" lalu "${cur.text}"`);
      problems++;
    }
  }
  const outFile = path.join('out/transcripts', `${name}.json`);
  fs.writeFileSync(
    outFile,
    JSON.stringify({video: 'input/raw.mp4', model: MODEL, words: merged}, null, 2)
  );
  console.log(
    `[merge] ${merged.length} kata -> ${outFile} (${problems} masalah sambungan)`
  );
  process.exit(problems === 0 ? 0 : 2);
}

console.error('Mode tidak dikenal. Pakai: calib | part N START DUR | merge NAME SPLIT...');
process.exit(1);
