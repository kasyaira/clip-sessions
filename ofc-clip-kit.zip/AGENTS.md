# OFC CLIP KIT — Kontrak Operasi untuk AI Agent

> **Kamu (agent) sedang memakai preset render klip vertikal milik @ofkiehme.**
> Style visual project ini **DIKUNCI**. Tugasmu HANYA memotong video mentah jadi klip
> dan menjalankan pipeline. Jangan mengubah style kecuali user memintanya secara eksplisit.
>
> **WAJIB baca dulu: `SKILL.md`** — entrypoint operasional (urutan baca file,
> aturan cache-pack, aturan render-retry). Lalu **`CATATAN-TEKNIS.md`** — runbook
> dari agent yang sudah menjalankan pipeline ini sampai sukses: environment
> constraints, error yang pernah terjadi + solusinya, parameter render yang
> terbukti cepat, dan pola render foreground untuk sandbox. Ikuti metode di
> sana; jangan research ulang.

## Langkah 0 (WAJIB, sebelum apapun lain)

```bash
bash scripts/bootstrap.sh
```

Idempoten — aman dipanggil di awal setiap sesi baru, termasuk setelah sandbox
di-reset. Script ini menangani npm install, cmake (tanpa sudo), build
whisper.cpp, download model, dan download Chrome headless shell milik Remotion
— **jangan lakukan langkah-langkah itu manual satu-satu**. Kalau di akhir
script ini muncul instruksi untuk memberi tahu user soal `clip-kit-cache.tar.gz`,
**sampaikan itu ke user apa adanya** (nama file, ukuran, dan bahwa file itu perlu
di-download & dikirim ulang di sesi berikutnya supaya sesi depan jauh lebih cepat).

## Spesifikasi output (terkunci)

| Hal | Nilai |
|---|---|
| Kanvas | 1080 x 1920 (portrait), 30 fps |
| Codec | H.264 + audio asli |
| Background blocking | Tekstur kertas krem + grain halus (bawaan) |
| Subtitle | Chunk 2-4 kata, pop per kata, putih outline hitam, Poppins ExtraBold |
| Watermark | @ofkiehme (atas-tengah) |
| Progress bar | Garis tipis di tepi atas |

## Tugas yang BOLEH kamu lakukan

1. Menaruh video mentah ke `public/input/`
2. Membuat / mengedit `render-inputs/clips.json` (sheet potongan)
3. Menjalankan command pipeline di bawah
4. Melaporkan hasil render di `out/clips/`

## Yang JANGAN kamu lakukan

- JANGAN mengedit file di dalam `src/` (kecuali user meminta perubahan style global —
  dan kalau iya, cukup `src/config.ts`, bukan komponen)
- JANGAN mengubah `COMPOSITION_ID`, nama komposisi, atau struktur data
- JANGAN me-render komposisi lain
- JANGAN mengubah `remotion.config.ts`

## Pipeline (setelah langkah 0 / bootstrap di atas)

```bash
# 1) taruh video mentah
#    cp /path/to/mentah.mp4 public/input/raw.mp4

# 2) transkrip word-level (whisper.cpp; run pertama download model ±466MB)
npm run transcribe -- public/input/raw.mp4

# 3) buat sheet potongan
cp render-inputs/clips.example.json render-inputs/clips.json
#    lalu edit render-inputs/clips.json:
#    {
#      "video": "input/raw.mp4",
#      "clips": [
#        {"id": "clip-01", "start": 0,    "end": 45},
#        {"id": "clip-02", "start": 120.5, "end": 200}
#      ]
#    }
#    ATURAN:
#    - start/end = detik di video sumber (boleh desimal, mis. 120.5)
#    - durasi tiap klip 40-180 detik (40 detik s/d 3 menit)
#    - pilih rentang yang berisi 1 ide/point utuh, hindari memotong di tengah kalimat
#    - id unik, format huruf/angka/-/_  (mis. clip-01, hook-kontroversi)

# 4) bangun data + render SEMUA klip sekaligus
npm run build-data
npm run render
#    klip panjang (> ~50 detik) / sandbox terbatas -> pakai wrapper retry:
#    bash scripts/render-retry.sh <nama-file-di-out/data-tanpa-.json>
```

Hasil akhir: `out/clips/<id>.mp4`

Untuk me-render ulang satu klip saja: `npm run render -- --only clip-01`

## Validasi sebelum melapor selesai

- [ ] `npm run build-data` tidak ada peringatan durasi (< 40s atau > 180s)
- [ ] Jumlah file di `out/data/` == jumlah klip di sheet
- [ ] Semua klip ter-render di `out/clips/` tanpa error
- [ ] Subtitle muncul & timing masuk akal (cek sekilas via `npm run studio` bila perlu)

## Schema data klip (out/data/*.json — dihasilkan otomatis, jangan diedit manual)

```jsonc
{
  "id": "clip-01",
  "video": "input/raw.mp4",   // path relatif terhadap public/
  "clipStart": 120.5,          // detik di video sumber
  "clipEnd": 200,
  "words": [                   // timing relatif ke awal klip (detik)
    {"text": "kata", "start": 0.5, "end": 0.8}
  ]
}
```

## Troubleshooting

(Semua baris di bawah ini sudah TERBUKTI di environment nyata — detail lengkap di `CATATAN-TEKNIS.md`)

| Masalah | Solusi |
|---|---|
| Install whisper gagal (butuh cmake), sandbox tanpa sudo | `export PATH="$HOME/.venv/bin:$PATH" && pip install cmake` — **JANGAN pakai apt** (tidak ada sudo). Detail: §2 CATATAN-TEKNIS.md |
| Render super lambat (1 fps) / Chrome crash di Linux | Remotion default `--single-process` + `/dev/shm` kecil → `chromiumOptions: {enableMultiProcessOnLinux: true}` di selectComposition **DAN** renderMedia + `concurrency: 2` + `x264Preset: 'veryfast'`. Detail: §4 |
| Proses render background mati sendiri | Sandbox bunuh proses background saat tool call berakhir → render foreground dalam 1 panggilan + poll log. Detail: §5 |
| Glitch audio di batas segmen concat | Render muted, mux audio asli dari video sumber. Detail: §6 |
| Timing subtitle null / kata sampah `[_BEG_]` / kata terpecah | Semua sudah dipatch di `scripts/transcribe.mjs` (API drift v4.0.526, filter token, fix merging). Jangan pakai API lama. Detail: §7 |
| Bahasa transkrip salah (EN padahal audio Indonesia) | `npm run transcribe -- public/input/raw.mp4 --language id` + field `"transcript": "raw-id.json"` di clips.json. Detail: §7 |
| Model whisper besar/lama | Turunkan: `npm run transcribe -- public/input/raw.mp4 --model base` |
| Audio/video tidak sinkron | Video sumber kemungkinan VFR — konversi ke CFR 30fps dulu (lihat `public/input/README.txt` + §3 CATATAN-TEKNIS.md) |
| `npx remotion ffmpeg` gagal | Install ffmpeg sistem, script otomatis memakainya bila tersedia |
| Preview style | `npm run studio` lalu buka http://localhost:3000 — komposisi `VerticalClip` |

## Catatan penting soal konsistensi

- Timing subtitle berasal dari whisper (word-level) — jangan dibuat-buat manual.
- Chunking 2-4 kata dilakukan otomatis oleh `src/helpers/chunker.ts` (deterministik).
- Semua angka style (font size, warna, posisi, watermark, durasi hold) ada di `src/config.ts`.
  Perubahan di file itu berlaku seragam ke SEMUA klip — inilah yang menjaga style konsisten.
