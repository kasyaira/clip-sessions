Taruh video mentahan di folder ini, contoh:
  public/input/raw.mp4

Lalu di render-inputs/clips.json isi: "video": "input/raw.mp4"
(path-nya relatif terhadap folder public/, TANPA awalan "public/").

Format yang disarankan: MP4 H.264 constant frame rate (CFR).
Kalau videonya VFR, konversi dulu:
  ffmpeg -i mentah.mp4 -vsync cfr -r 30 -c:v libx264 -crf 18 -c:a aac raw.mp4
