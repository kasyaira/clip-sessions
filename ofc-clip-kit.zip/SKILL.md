---
name: ofc-clip-kit-ops
description: Cara mengoperasikan preset render klip vertikal @ofkiehme (Remotion) di sandbox agent yang sering di-reset. WAJIB dipakai setiap kali diminta memproses video jadi klip TikTok/Reels/Shorts dari project ofc-clip-kit.
---

# ofc-clip-kit-ops

Kamu adalah agent yang menjalankan **ofc-clip-kit** (preset Remotion klip vertikal,
lihat `README.md`). Skill ini adalah **entrypoint wajib** — baca ini duluan,
sebelum menyentuh file apapun.

## Aturan #1 — jangan research ulang, jangan improvisasi

Semua masalah environment di sandbox ini (whisper.cpp butuh cmake tanpa sudo,
render 1fps di Linux, proses background dibunuh, dsb) **sudah pernah terjadi
dan sudah dipecahkan**. Solusinya sudah ditanam di script, bukan cuma ditulis
di dokumen. Urutan baca/eksekusi:

1. **`bash scripts/bootstrap.sh`** ← jalankan ini DULU, selalu, di awal sesi.
   Idempoten & aman dipanggil berkali-kali. Ini menggantikan semua langkah
   manual `npm install` / `pip install cmake` / build whisper.cpp / download
   Chrome — jangan lakukan langkah-langkah itu satu-satu secara manual.
2. `AGENTS.md` — kontrak tugas (apa yang boleh/tidak boleh kamu ubah) +
   pipeline 4 langkah.
3. `CATATAN-TEKNIS.md` — kalau ada error yang tidak tertangani bootstrap,
   cek di sini dulu sebelum mencoba solusi sendiri. Referensi lengkap penyebab
   & fix yang sudah terbukti.

## Aturan #2 — cache-pack: sandbox reset ≠ mulai dari nol

Sandbox ini kemungkinan akan di-reset total (semua file hilang) kalau tidak
dipakai beberapa jam. `bootstrap.sh` menangani ini lewat **cache-pack**
(`clip-kit-cache.tar.gz`, berisi whisper.cpp yang sudah ter-build + model +
Chrome headless shell milik Remotion):

- **Kalau user mengirim ulang `clip-kit-cache.tar.gz` bersama zip project** →
  taruh di root project, lalu jalankan `bootstrap.sh` seperti biasa — dia akan
  extract otomatis (hitungan detik, bukan menit).
- **Kalau ini pertama kali / tidak ada cache-pack** → `bootstrap.sh` build dari
  nol SEKALI, lalu otomatis membuat `clip-kit-cache.tar.gz` di akhir.
- **SETIAP kali `bootstrap.sh` selesai membuat/refresh cache-pack, kamu WAJIB
  memberi tahu user secara eksplisit**: sebutkan nama file, ukurannya, dan
  minta mereka download filenya sekarang serta kirim ulang bareng zip project
  di sesi berikutnya. Jangan biarkan file itu tertinggal begitu saja di
  sandbox — sandbox akan di-reset dan file itu ikut hilang kalau tidak
  di-download user.

## Aturan #3 — render: pakai wrapper retry, jangan render mentah

- Klip pendek (< ~50 detik): `npm run render` cukup.
- Klip panjang: **`bash scripts/render-retry.sh <nama-data>`** (bukan memanggil
  `render-segments.mjs` langsung berkali-kali secara manual). Wrapper ini sudah
  menangani retry otomatis + foreground execution (proses background dibunuh
  sandbox saat tool call berakhir — lihat §5 `CATATAN-TEKNIS.md`).
- Kalau render gagal/timeout, JANGAN tunggu lama untuk memutuskan retry —
  wrapper sudah punya timeout pendek per percobaan. Percayakan ke wrapper.

## Aturan #4 — style terkunci

Style visual (`src/config.ts` dst.) sudah final. Jangan diubah kecuali user
minta eksplisit. Detail lengkap ada di `AGENTS.md`.

## Ringkasan alur kerja per sesi

```
1. bash scripts/bootstrap.sh                       # selalu pertama
2. cp video mentah -> public/input/raw.mp4
3. npm run transcribe -- public/input/raw.mp4 --language id
4. edit render-inputs/clips.json
5. npm run build-data
6. npm run render                                  # klip pendek
   ATAU bash scripts/render-retry.sh <nama-data>    # klip panjang
7. laporkan hasil di out/clips/, DAN ingatkan user soal clip-kit-cache.tar.gz
   kalau bootstrap barusan membuat/refresh file itu.
```
