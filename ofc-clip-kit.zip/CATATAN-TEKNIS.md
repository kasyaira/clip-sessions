# CATATAN TEKNIS — ofc-clip-kit (Runbook Agent)

> **Ditulis oleh agent yang sudah menjalankan pipeline ini end-to-end sampai sukses**
> (video 158 detik → render utuh 4754 frame, plus iterasi revisi).
> Tujuan: agent berikutnya **tidak perlu research ulang** — ikuti saja metode yang
> terbukti di sini, dan jangan ulangi error yang sudah pernah terjadi.
> Baca berurutan: `AGENTS.md` (kontrak) → dokumen ini (cara teknis) → `CATATAN-REVISI.md` (riwayat revisi).

---

## 0. Environment tempat kit ini terbukti jalan

| Kondisi | Nilai | Konsekuensi |
|---|---|---|
| Node | v24.21.0 | import CJS default untuk `@remotion/install-whisper-cpp` |
| RAM | 4 GB | `concurrency: 2` aman; jangan lebih tinggi |
| `/dev/shm` | **hanya 64 MB** | penyebab Chrome crash; WAJIB multi-process (lihat §4) |
| Sudo | **tidak ada** | `apt install` GAGAL → cmake via pip (lihat §2) |
| Proses background | **dibunuh saat tool call berakhir** | render harus foreground dalam 1 panggilan (lihat §5) |
| cmake | tidak terinstall | jangan pakai apt; pakai pip venv |

---

## 1. Pipeline yang TERBUKTI jalan (urutan pasti)

```bash
# 0) dependency
npm install

# 0b) cmake bila belum ada (sandbox tanpa sudo — lihat §2)
export PATH="$HOME/.venv/bin:$PATH" && pip install cmake

# 1) video mentah → WAJIB konversi ke CFR 30fps dulu (lihat §3)
ffmpeg -y -i mentah.mp4 -vf fps=30 -c:v libx264 -crf 18 -preset medium \
  -c:a aac -b:a 192k public/input/raw.mp4

# 2) transkrip word-level (run pertama: build whisper.cpp + download model ±466MB)
npm run transcribe -- public/input/raw.mp4 --language id     # paksa bahasa Indonesia
#    → out/transcripts/raw-id.json   (cache: out/tmp/*.whisper-cache-*.json)

# 3) sheet potongan
#    render-inputs/clips.json — 1 entri = 1 klip utuh, atau beberapa potongan
#    field "transcript": "raw-id.json" untuk memilih transkrip sumber

# 4) build data + render
npm run build-data
node scripts/render-segments.mjs     # klip panjang (> ~50s) — WAJIB pakai ini
npm run render                       # klip pendek saja

# 5) gabung segmen + audio (lihat §6)
```

Angka waktu yang terukur (video 158s, 4754 frame):
- Build whisper.cpp v1.7.3 (make): beberapa menit, sekali saja.
- Download model `ggml-small.bin` (466MB): ±40 detik.
- Transkripsi word-level model small: cepat (menit pertama), dan **tidak diulang**
  karena cache.
- Render DENGAN fix multi-process: **±4-5 fps** (≈16-20 menit untuk 4754 frame,
  dibagi 3 segmen). Render TANPA fix: **1 fps** (10x lebih lambat!).

## 2. cmake tanpa sudo (jangan pakai apt!)

`AGENTS.md` lama menyarankan `apt install cmake` — **gagal** di sandbox tanpa sudo.
Metode yang berhasil:

```bash
export PATH="$HOME/.venv/bin:$PATH"
pip install cmake
```

Build whisper.cpp pakai `make` biasa di folder `whisper.cpp/` → binary ada di
`build/bin/main`. `scripts/transcribe.mjs` mengharapkan binary jalan dengan
nama/path `whisper.cpp/main` — sudah ditangani symlink. Versi dipin **1.7.3**
karena pada 1.7.3 hasil build `make` menaruh binary sesuai path yang dibaca SDK;
jangan asal naikkan versi.

## 3. Video sumber VFR → CFR (WAJIB, jangan skip)

Video mentah podcast sering 24fps VFR. Kalau langsung dipakai: **audio/video drift**
selama beberapa menit. Selalu konversi ke CFR 30fps dulu (perintah di §1 langkah 1).
Cek sumber dulu: `ffprobe -select_streams v -show_entries stream=r_frame_rate,avg_frame_rate,nb_frames video.mp4`.

## 4. Render lambat 1 fps di Linux — penyebab & fix

Default Remotion di Linux menjalankan Chrome Headless dengan `--single-process`.
Di sandbox ini (dan banyak container) itu membuat render **1 fps** dan/atau Chrome
crash karena `/dev/shm` cuma 64 MB. Fix yang terbukti (sudah dipasang di
`scripts/render-all.mjs` dan `scripts/render-segments.mjs`):

```js
chromiumOptions: { enableMultiProcessOnLinux: true },  // di selectComposition DAN renderMedia
concurrency: 2,        // RAM 4GB — jangan naikkan
x264Preset: 'veryfast',
imageFormat: 'jpeg',
jpegQuality: 90,
```

Hasil: 4-5x lebih cepat. **Kedua tempat** (selectComposition + renderMedia) harus
diberi `chromiumOptions` — hanya satu tidak cukup.

## 5. Pola render foreground (sandbox bunuh proses background)

Proses yang di-`&`-kan akan mati begitu tool call berakhir (bukan OOM — cek
`oom_kill` 0). Render harus **foreground dalam satu panggilan** dengan polling:

```bash
(cd /path/ke/clip-kit && exec node scripts/render-segments.mjs) > out-render.log 2>&1
# panggilan tool diberi timeout panjang (mis. 600000 ms), lalu pantau:
# tail -c 400 out-render.log   (progress % muncul di baris terakhir)
```

Untuk klip panjang, `render-segments.mjs` memecah per **±1584 frame (±52.8s)**
agar muat dalam satu sesi. IDEMPOTEN: segmen yang sudah ada dilewati, jadi kalau
putus, cukup jalankan lagi.

## 6. Audio: render muted + mux audio asli (bebas glitch)

Jangan render audio ikut per segmen — muncul glitch AAC di batas segmen. Pola
terbukti (video muted, audio asli di-mux saat concat):

```bash
ls out/segments/seg-*.mp4 | sort | xargs -n1 basename | sed "s/^/file '/;s/$/'/" > out/segments/concat.txt
ffmpeg -y -f concat -safe 0 -i out/segments/concat.txt -c:v copy out/tmp/nosound.mp4
ffmpeg -y -i public/input/raw.mp4 -t <durasi_klip> -vn -c:a copy out/tmp/audio.m4a
ffmpeg -y -i out/tmp/nosound.mp4 -i out/tmp/audio.m4a -map 0:v -map 1:a -c copy -shortest out/clips/<id>.mp4
```

Validasi hasil concat: jumlah frame `nosound.mp4` harus == total frame render
(`ffprobe -count_frames -select_streams v -show_entries stream=nb_read_frames ...`).

## 7. API drift `@remotion/install-whisper-cpp` v4.0.526 (semua sudah dipatch)

Contoh error & akar masalah (sudah diperbaiki di `scripts/transcribe.mjs`, jangan
dikembalikan ke API lama):

| Gejala | Akar masalah | Fix |
|---|---|---|
| `getWhisperCppVersion is not a function` | named export sudah dihapus di v4.0.526 | default import + versi dipin `'1.7.3'` |
| `toTemporary is not a function` | opsi berubah nama | `installWhisperCpp({version, to: 'whisper.cpp'})` |
| whisper `unknown argument` palsu | `inputPath` relatif; binary jalan dengan `cwd=whisper.cpp` | `inputPath: path.resolve(wavPath)` |
| Semua timing null | format token baru | `tok.offsets.from / 1000` dan `tok.offsets.to / 1000` (ms) |
| Kata sampah `[_BEG_]`, `[_TT_75]` | token spesial whisper | filter `^\[_\w+\]$` DAN `\[_TT_\d+\]` (versi nempel) |
| `"tanya"` terpecah `"t anya"` | accumulator kata ada DI DALAM loop segmen; dengan `--max-len 1` satu kata bisa membentang antar segmen | accumulator `cur` pindah ke luar loop segmen; flush hanya di akhir |
| Transkrip bahasa salah (EN padahal audio ID) | auto-detect keliru di audio campuran | flag `--language id` (default auto), cache per model+bahasa |

## 8. Konfigurasi style yang boleh disentuh

- `src/config.ts`: semua angka style. `VIDEO.centerY` (0.44) = posisi kartu video
  naik ±115px — dipakai agar subtitle template tidak menimpa subtitle burn-in
  yang sering ada di video sumber. Subtitle: `SUBTITLE.centerY`.
- `src/project.json`: `lead: 0` (klip mulai detik 0 → subtitle sinkron persis);
  `tail: 0.45`.
- Kalau video sumber juga punya subtitle burn-in, posisi aman: video agak ke atas,
  subtitle template di bawah — cek 2-3 frame hasil render sebelum delivery
  (mis. t=10s, 62s, 130s) via ekstrak frame `ffmpeg -ss <t> -i out.mp4 -frames:v 1`.

## 9. Checklist delivery (jangan lewat)

- [ ] `ffprobe` output: 1080x1920, 30fps, h264 + aac
- [ ] Jumlah frame video final == total frame render
- [ ] Cek visual 2-3 frame tersebar: subtitle sinkron, tidak menimpa burn-in sumber
- [ ] Zip template TANPA `node_modules/`, `whisper.cpp/`, `public/input/raw.mp4`,
      `out/segments/`, `out/tmp/`, `out/clips/`, log
- [ ] Sertakan `out/transcripts/` + `out/data/` di zip (hasil kerja ikut terkirim)
- [ ] Worklog diupdate

## 11. Sandbox di-reset total tiap beberapa jam → cache-pack (§11, penting)

Masalah nyata: kalau sandbox idle beberapa jam, SEMUA isi hilang (bukan cuma
proses) — `node_modules/`, `whisper.cpp/` (build+model), Chrome headless shell
Remotion (`node_modules/.remotion/`). Tanpa penanganan, tiap sesi baru = ulang
dari nol: `pip install cmake` (§2), build whisper.cpp (menit), download model
466MB, download Chrome headless shell (~menit lagi, tergantung bandwidth) —
dan proses ini sering gagal di tengah (network flaky), agent baru sadar harus
retry setelah menunggu lama.

Fix: `scripts/bootstrap.sh` + `scripts/warm-whisper.mjs`, dengan mekanisme
**cache-pack** (`clip-kit-cache.tar.gz` di root project):

- Isi cache-pack: `whisper.cpp/` (binary + model) dan `node_modules/.remotion/`
  (Chrome headless shell — lokasi ini dikonfirmasi dari dokumentasi Remotion:
  `node_modules/.remotion/chrome-headless-shell`). Mode `--full` juga meng-cache
  seluruh `node_modules/` (skip `npm install` juga, tapi filenya jadi jauh lebih
  besar — pakai hanya kalau sandbox konsisten sama arch/OS tiap sesi).
- `bootstrap.sh` cek dulu apakah `clip-kit-cache.tar.gz` ada di root → kalau
  ada, `tar xzf` (hitungan detik) dan SKIP semua build/download. Kalau tidak
  ada, build dari nol dengan retry+timeout per langkah (jangan menunggu sampai
  tool-call timeout baru tahu gagal), lalu di akhir BUAT cache-pack baru.
- **Cache-pack TIDAK ikut ter-reset sendiri karena dia bukan disimpan di
  sandbox** — dia harus di-download user lalu di-upload ulang di sesi
  berikutnya bersama zip project. Kalau agent selesai bikin/refresh cache-pack
  dan tidak mengingatkan user untuk download filenya, kerja itu sia-sia (hilang
  lagi pas sandbox direset).
- `warm-whisper.mjs` cuma memaksa `installWhisperCpp` + `downloadWhisperModel`
  jalan SEKARANG (tanpa perlu video), supaya build+download whisper terjadi
  saat bootstrap (bisa diukur & di-retry), bukan lazy saat `transcribe.mjs`
  jalan pertama kali di tengah pipeline.
- Render klip panjang: pakai `scripts/render-retry.sh <nama-data>` alih-alih
  memanggil `render-segments.mjs` manual berulang — wrapper ini looping
  otomatis dengan timeout pendek per percobaan (segmen yang sudah jadi tetap
  idempoten, lihat §5).

Baca `SKILL.md` untuk ringkasan alur operasional lengkap (ini adalah
entrypoint yang seharusnya dibaca agent duluan, sebelum file ini).

## 13. Temuan dari sesi nyata (sudah diperbaiki di kode — bukan manual lagi)

Dua bug ini ditemukan lewat log agent yang benar-benar menjalankan pipeline
sampai render 7 klip panjang. Keduanya SUDAH dipatch langsung di script, jadi
baris di bawah ini murni catatan "kenapa", bukan langkah yang perlu diulang.

**a) `/tmp` penuh (ENOSPC) setelah beberapa kali render panjang.**
`bundle()` dari `@remotion/bundler`, kalau tidak diberi `outDir`, menulis ke
folder temp ACAK tiap kali dipanggil (~800MB+, termasuk copy penuh `public/`
— video mentah ikut ter-duplikasi tiap panggilan). `render-retry.sh` memanggil
`render-segments.mjs` berkali-kali tiap retry → tiap panggilan = 1 bundle baru
yang menumpuk, tidak pernah dibersihkan. Di sesi nyata ini bikin disk
9.5GB habis (ENOSPC) setelah ±2 klip. Fix: `render-segments.mjs` dan
`render-all.mjs` sekarang selalu pakai `outDir: path.resolve('.remotion-bundle')`
— folder tetap di root project, di-overwrite tiap panggilan, tidak pernah
menumpuk. `render-retry.sh` juga membersihkan sisa bundle lama di `/tmp`
(dari sebelum fix ini ada) sebagai safety-net.

**b) Symlink `whisper.cpp/main` hilang lagi tiap build fresh.**
SDK & `transcribe.mjs` mengharapkan binary di `whisper.cpp/main`, tapi hasil
`make` menaruhnya di `whisper.cpp/build/bin/main` (lihat §2). Catatan lama
bilang "sudah ditangani symlink", tapi symlink itu dibuat manual oleh agent
sesi sebelumnya dan TIDAK ikut tersimpan — begitu bootstrap build ulang dari
nol (atau restore dari cache-pack lama yang dibuat sebelum fix ini), symlink-nya
tidak ada lagi dan `transcribe.mjs` gagal jalan. Fix: `bootstrap.sh` sekarang
punya fungsi `ensure_whisper_symlink` yang dipanggil otomatis setelah extract
cache-pack DAN setelah build whisper.cpp — jadi symlink selalu ada tanpa
campur tangan manual.

**c) Model whisper "hilang" — sebenarnya cuma salah folder.**
Kalau ada folder `models/` di root berisi file kecil (±575KB, biasanya
placeholder/stub dari clone `whisper.cpp` sendiri), itu BUKAN model asli.
Model asli (±466MB) ada di `whisper.cpp/ggml-<nama-model>.bin` (folder yang
sama dengan tempat `installWhisperCpp`/`downloadWhisperModel` menaruh
semuanya — lihat `WHISPER_DIR` di `scripts/transcribe.mjs`). Jangan habiskan
waktu mencari model di tempat lain.

## 14. File yang berisi patch penting

| File | Patch yang ada di dalamnya |
|---|---|
| `scripts/transcribe.mjs` | semua fix API drift + filter token + fix merging + cache + flag `--language` |
| `scripts/render-all.mjs` | multi-process fix + concurrency/preset untuk render cepat |
| `scripts/render-segments.mjs` | render klip panjang per segmen, idempoten, muted |
| `src/config.ts` | `VIDEO.centerY` (posisi video) + seluruh angka style |
| `src/project.json` | `lead: 0` sinkronisasi subtitle klip utuh |
| `scripts/bootstrap.sh` | setup idempoten + cache-pack (lihat §11) |
| `scripts/warm-whisper.mjs` | front-load build whisper.cpp + download model (dipanggil bootstrap) |
| `scripts/render-retry.sh` | wrapper auto-retry untuk render klip panjang (lihat §11) + cleanup `/tmp` lama (§13a) |
| `scripts/render-segments.mjs`, `scripts/render-all.mjs` | `outDir` tetap untuk `bundle()`, cegah `/tmp` penuh (§13a) |
| `scripts/bootstrap.sh` (`ensure_whisper_symlink`) | jaga symlink `whisper.cpp/main` tetap ada (§13b) |
| `SKILL.md` | entrypoint operasional ringkas untuk agent (baca duluan) |
