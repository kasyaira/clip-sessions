# OFC CLIP KIT

Preset **Remotion** untuk memproduksi klip vertikal (1080x1920 • 30fps) secara **konsisten**
dari video mentahan podcast/vlog. Style sudah dikunci di satu file config supaya setiap klip —
dan setiap sesi render, oleh agent siapapun — menghasilkan look yang sama persis.

```
Video mentah ──▶ transcribe (whisper, word-level) ──▶ sheet potongan ──▶ build data ──▶ render batch
                  out/transcripts/*.json              render-inputs/       out/data/       out/clips/*.mp4
```

## Fitur preset

- **Portrait 1080x1920 @ 30fps** — video 16:9 dipasang sebagai kartu di tengah frame
- **Background blocking "kertas"** — tekstur kertas krem hangat full-frame + grain film halus,
  jadi area atas/bawah terasa sengaja didesain, bukan dipaksa vertikal
- **Subtitle popup mengikuti irama bicara** — chunk 2-4 kata muncul serentak dengan efek
  pop/bounce per kata; kata yang sedang diucap sedikit membesar, sisanya meredup;
  timing berasal dari transkrip whisper **word-level** (bukan tebakan)
- **Watermark @ofkiehme** di atas-tengah
- **Progress bar** tipis di tepi atas
- **CLI batch render** — 1 command untuk semua klip
- Font Poppins (ExtraBold/SemiBold/Medium) sudah **bundled lokal** — render tidak butuh internet

## Instalasi

```bash
bash scripts/bootstrap.sh
```

Syarat: Node.js >= 18. Script ini idempoten dan menggantikan `npm install` +
build whisper.cpp + download model + download Chrome headless shell Remotion
dalam satu langkah — aman dipanggil ulang kapan saja (misalnya di awal setiap
sesi agent baru). Kalau ini sandbox sementara yang sering di-reset (mis. agent
AI), lihat bagian **Sandbox yang sering di-reset (cache-pack)** di bawah.

## Cara pakai cepat

```bash
# 1. taruh video mentah
cp /path/to/mentah.mp4 public/input/raw.mp4

# 2. transkrip (sekali per video)
npm run transcribe -- public/input/raw.mp4

# 3. tentukan potongan
cp render-inputs/clips.example.json render-inputs/clips.json
#    edit: {"video": "input/raw.mp4", "clips": [{"id": "clip-01", "start": 0, "end": 45}, ...]}

# 4. build data + render semua
npm run build-data
npm run render
```

Hasil: `out/clips/<id>.mp4` — siap upload ke Reels/TikTok/Shorts.

Perintah lain yang berguna:

| Command | Fungsi |
|---|---|
| `npm run studio` | Preview style di browser (localhost:3000), pakai data demo |
| `npm run render -- --only clip-01` | Render ulang satu klip saja |
| `npm run transcribe -- <video> --model base` | Transkrip dengan model lebih ringan/cepat |
| `npm run typecheck` | Cek tipe TypeScript |

> **Kirim project ini ke AI agent?** Sertakan file `SKILL.md` dan `AGENTS.md`
> (ada di root) — itu kontrak operasinya: agent cukup ikuti langkah di sana
> tanpa bisa merusak style.

## Sandbox yang sering di-reset (cache-pack)

Kalau kit ini dijalankan lewat AI agent dengan sandbox sementara (isi sandbox
hilang total tiap beberapa jam tidak dipakai), bagian paling lambat & paling
sering error adalah build whisper.cpp + download model (±466MB) + download
Chrome headless shell Remotion — semuanya kerjaan deterministik yang seharusnya
tidak perlu diulang tiap sesi.

`scripts/bootstrap.sh` menangani ini dengan **cache-pack**:

1. Sesi pertama: `bash scripts/bootstrap.sh` build semuanya sekali, lalu
   otomatis membungkusnya jadi `clip-kit-cache.tar.gz` di root project.
2. **Download `clip-kit-cache.tar.gz` itu** dan simpan di komputer kamu.
3. Sesi berikutnya (setelah sandbox di-reset): upload ulang zip project ini
   **+ `clip-kit-cache.tar.gz`**, lalu minta agent jalankan
   `bash scripts/bootstrap.sh` lagi — kali ini dia tinggal extract (hitungan
   detik), tidak build/download ulang.

Kalau kamu memakai AI agent yang punya sistem "skill" sendiri (bisa dipasang
instruksi mandiri), suruh dia membaca `SKILL.md` di root project — file itu
isinya kontrak singkat "jalankan bootstrap.sh dulu, jangan research ulang,
ingatkan soal cache-pack" supaya agent tidak perlu diberi tahu ulang tiap
sesi.

## Struktur project

```
ofc-clip-kit/
├── AGENTS.md                  # kontrak operasi untuk AI agent
├── remotion.config.ts
├── package.json
├── render-inputs/
│   └── clips.example.json     # template sheet potongan
├── public/
│   ├── fonts/                 # Poppins (bundled, offline)
│   ├── input/                 # <-- video mentah ditaruh di sini
│   └── textures/              # tekstur kertas + grain (bawaan preset)
├── scripts/
│   ├── transcribe.mjs         # step 1: video -> word timestamps
│   ├── build-clips.mjs        # step 2: sheet potongan -> data per klip
│   └── render-all.mjs         # step 3: render batch semua klip
└── src/
    ├── config.ts              # ★ SINGLE SOURCE OF TRUTH — semua style di sini
    ├── project.json           # id komposisi + padding lead/tail
    ├── Root.tsx               # registrasi komposisi "VerticalClip"
    ├── types.ts / schemas.ts
    ├── helpers/chunker.ts     # aturan chunk 2-4 kata (deterministik)
    ├── components/            # PaperBackground, Subtitles, ProgressBar, Watermark
    ├── vertical-clip/VerticalClip.tsx  # template utama klip
    └── data/demo-words.json   # kata demo untuk studio preview
```

## Kustomisasi style (opsional)

Semua ada di **`src/config.ts`** — ubah sekali, berlaku ke semua klip:

| Key | Mengatur |
|---|---|
| `SUBTITLE.fontSize` / `color` / `strokeWidth` | Ukuran, warna, ketebalan outline subtitle |
| `SUBTITLE.centerY` | Posisi vertikal blok subtitle (0.595 = sepertiga bawah video) |
| `SUBTITLE.chunk.preferWords` / `maxWords` | Jumlah kata per popup |
| `SUBTITLE.activeWord` | Efek kata aktif (scale/dim) — bisa dimatikan |
| `WATERMARK.text` / `top` / `color` | Watermark |
| `PAPER` / `GRAIN` | Tekstur kertas & grain (opacity, animasi) |
| `VIDEO.radius` / `boxShadow` / `volume` | Kartu video & volume audio |
| `PROGRESS_BAR` | Progress bar |
| `src/project.json` → `lead`/`tail` | Padding napas di awal/akhir klip |

## Troubleshooting

- **Install whisper.cpp gagal** → butuh cmake: `apt install build-essential cmake` (Linux) /
  `brew install cmake` (macOS)
- **Transkrip kurang akurat** → naikkan model: `--model medium`
- **A/V tidak sinkron** → video sumber VFR; konversi ke CFR dulu (lihat `public/input/README.txt`)
- **Ingin klip tanpa subtitle** (mis. bagian musik) → boleh, `build-data` akan memperingatkan
  bahwa rentang itu tidak punya kata; render tetap jalan
