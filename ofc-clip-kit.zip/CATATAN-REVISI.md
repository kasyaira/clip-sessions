# CATATAN REVISI — ofc-clip-kit (fixed)

Revisi atas permintaan user (3 poin) + perbaikan kompatibilitas pipeline.
**Dokumen pendamping:** `CATATAN-TEKNIS.md` (runbook lengkap: environment, error yang pernah
terjadi + solusinya, parameter render terbukti). Baca itu dulu sebelum menjalankan pipeline.

## 1. Subtitle Bahasa Indonesia (sesuai isi video)
- `npm run transcribe` sekarang mendukung flag bahasa:
  ```bash
  npm run transcribe -- public/input/raw.mp4 --language id
  ```
- Transkrip aktif: `out/transcripts/raw-id.json` (whisper small, word-level, dipaksa bahasa Indonesia).
- `render-inputs/clips.json` punya field baru `"transcript": "raw-id.json"` untuk menunjuk transkrip tertentu.
- Fix bug merging sub-kata di `scripts/transcribe.mjs`: accumulator kata dipindah ke luar loop segmen
  (dengan `--max-len 1`, satu kata bisa membentang antar segmen — sebelumnya "tanya" terpecah jadi "t anya").

## 2. Video card digeser ke atas
- `src/config.ts` → properti baru `VIDEO.centerY` (fraksi tinggi kanvas; 0.5 = tengah).
  Nilai sekarang: **0.44** (kartu naik ±115px dari posisi lama).
- `src/vertical-clip/VerticalClip.tsx` membaca `VIDEO.centerY` (translateY) — tidak lagi hardcode center.
- Cukup ubah angka di config untuk mengatur lagi.

## 3. Satu klip utuh (tidak dipecah)
- `render-inputs/clips.json` sekarang berisi 1 klip: `{id: "video-utuh", start: 0, end: 158}`.
- `src/project.json`: `lead` 0.18 → **0** supaya subtitle sinkron persis saat klip mulai dari detik 0
  (lead tetap tersedia untuk klip yang dipotong dari tengah video).

## Perbaikan pipeline (kompatibilitas environment baru)
- `scripts/transcribe.mjs` diadaptasi ke `@remotion/install-whisper-cpp` v4.0.526:
  API baru (to:/downloadWhisperModel/whisperCppVersion/offsets ms), filter token `[_BEG_]/[_TT_xx]`,
  cache whisper per model+bahasa di `out/tmp/*.whisper-cache-*.json`.
- `scripts/render-all.mjs`: `enableMultiProcessOnLinux: true` + `concurrency: 2` + `x264Preset: veryfast`
  (di sandbox Linux, mode single-process bawaan bikin render 4-5x lebih lambat).
- Script baru `scripts/render-segments.mjs`: render klip panjang per segmen ±1584 frame (idempoten,
  aman diulang; video dirender muted lalu audio asli dari sumber di-mux saat penggabungan — bebas
  glitch AAC di batas segmen). Pemakaian:
  ```bash
  node scripts/render-segments.mjs                # pakai out/data/video-utuh.json
  # setelah semua segmen selesai, gabung:
  ls out/segments/seg-*.mp4 | sort | xargs -n1 basename | sed "s/^/file '/;s/$/'/" > out/segments/concat.txt
  ffmpeg -y -f concat -safe 0 -i out/segments/concat.txt -c:v copy out/tmp/nosound.mp4
  ffmpeg -y -i public/input/raw.mp4 -t <durasi> -vn -c:a copy out/tmp/audio.m4a
  ffmpeg -y -i out/tmp/nosound.mp4 -i out/tmp/audio.m4a -map 0:v -map 1:a -c copy -shortest out/clips/<id>.mp4
  ```

## Data hasil transkripsi (ikut dikirim)
- `out/transcripts/raw-id.json` — word-level Bahasa Indonesia (381 kata)
- `out/transcripts/raw.json` — word-level English (553 kata, versi lama)
- `out/data/video-utuh.json` — data klip siap render (timing kata relatif klip)

## Cara render ulang
```bash
npm install
npm run transcribe -- public/input/raw.mp4 --language id   # opsional, transkrip sudah ikut
npm run build-data
npm run render          # klip pendek; untuk klip panjang pakai render-segments.mjs
```
