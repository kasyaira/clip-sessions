import React, {useMemo} from 'react';
import {
  AbsoluteFill,
  OffthreadVideo,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {CANVAS, PAPER, TIMING, VIDEO} from '../config';
import type {ClipData} from '../types';
import {chunkWords} from '../helpers/chunker';
import {GrainOverlay, PaperBackground} from '../components/PaperBackground';
import {Subtitles} from '../components/Subtitles';
import {ProgressBar} from '../components/ProgressBar';
import {Watermark} from '../components/Watermark';

/** Durasi komposisi (frame) dihitung otomatis dari rentang potongan + padding */
export const clipDurationInFrames = (data: ClipData): number => {
  const seconds = data.clipEnd - data.clipStart + TIMING.lead + TIMING.tail;
  return Math.max(CANVAS.fps, Math.ceil(seconds * CANVAS.fps));
};

/**
 * OFC CLIP KIT — template klip vertikal @ofkiehme
 * Urutan layer (bawah -> atas):
 *   kertas -> kartu video -> grain -> subtitle -> watermark -> progress bar
 */
export const VerticalClip: React.FC<{data: ClipData}> = ({data}) => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();

  const chunks = useMemo(() => chunkWords(data.words), [data.words]);

  const videoH = Math.round((CANVAS.width * 9) / 16);
  const startFrom = Math.max(0, Math.round((data.clipStart - TIMING.lead) * fps));

  return (
    <AbsoluteFill
      style={{backgroundColor: PAPER.color, overflow: 'hidden'}}
    >
      <PaperBackground />

      {/* Video utama 16:9 sebagai kartu; posisi vertikal diatur VIDEO.centerY (0.5 = tengah) */}
      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
        <div
          style={{
            position: 'relative',
            width: CANVAS.width,
            height: videoH,
            transform: `translateY(${(VIDEO.centerY - 0.5) * CANVAS.height}px)`,
            borderRadius: VIDEO.radius,
            overflow: 'hidden',
            boxShadow: VIDEO.boxShadow,
            border: VIDEO.border,
            backgroundColor: '#141210',
          }}
        >
          {data.video ? (
            <OffthreadVideo
              src={staticFile(data.video)}
              startFrom={startFrom}
              volume={VIDEO.volume}
              style={{
                width: '100%',
                height: '100%',
                objectFit: 'cover',
              }}
            />
          ) : (
            <AbsoluteFill
              style={{
                justifyContent: 'center',
                alignItems: 'center',
                color: 'rgba(255,255,255,0.65)',
                fontFamily: 'Poppins',
                fontWeight: 600,
                fontSize: 32,
                textAlign: 'center',
                padding: 48,
                lineHeight: 1.5,
              }}
            >
              MODE DEMO — STYLE PREVIEW
              <br />
              (isi field "video" di file data untuk render asli)
            </AbsoluteFill>
          )}
        </div>
      </AbsoluteFill>

      <GrainOverlay />
      <Subtitles chunks={chunks} />
      <Watermark />
      <ProgressBar
        progress={durationInFrames > 1 ? frame / (durationInFrames - 1) : 0}
      />
    </AbsoluteFill>
  );
};
