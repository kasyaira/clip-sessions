import type {Chunk, Word} from '../types';
import {SUBTITLE} from '../config';

const STRONG_END = /[.!?…]["')\]]*$/;
const SOFT_END = /[,;:—–]["')\]]*$/;

/**
 * Gabungkan kata-kata (dari transkrip) menjadi chunk 2-4 kata.
 *
 * Aturan pemecahan (deterministik — input sama, hasil selalu sama):
 *  1. Wajib potong setelah tanda akhir kalimat ( . ! ? )
 *  2. Potong lembut setelah koma/titik dua bila chunk sudah >= 2 kata
 *  3. Potong bila jumlah kata sudah mencapai batas maksimal
 *  4. Potong bila ada jeda bicara panjang sebelum kata berikutnya (ritme natural)
 */
export function chunkWords(words: Word[]): Chunk[] {
  const {preferWords, maxWords} = SUBTITLE.chunk;
  const chunks: Chunk[] = [];
  let current: Word[] = [];

  const flush = () => {
    if (current.length > 0) {
      chunks.push({
        words: current,
        start: current[0].start,
        end: current[current.length - 1].end,
      });
      current = [];
    }
  };

  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    const next: Word | undefined = words[i + 1];
    current.push(word);

    if (STRONG_END.test(word.text)) {
      flush();
      continue;
    }
    if (current.length >= maxWords) {
      flush();
      continue;
    }
    if (SOFT_END.test(word.text) && current.length >= 2) {
      flush();
      continue;
    }
    if (next && current.length >= 2 && next.start - word.end > 0.55) {
      flush();
      continue;
    }
    if (
      next &&
      current.length >= preferWords &&
      next.start - word.end > 0.28
    ) {
      flush();
      continue;
    }
  }
  flush();

  // ---- balancing pass ----
  // chunk 1 kata di tengah stream jelek untuk ritme popup.
  // Solusi: pinjam kata terakhir chunk sebelumnya (mis. 4+1 -> 3+2),
  // atau gabungkan ke tetangga yang masih kecil.
  for (let i = 0; i < chunks.length; i++) {
    const c = chunks[i];
    if (c.words.length !== 1) continue;
    const prev = chunks[i - 1];
    const next = chunks[i + 1];
    if (prev && prev.words.length >= 3) {
      const moved = prev.words.pop();
      if (moved) c.words.unshift(moved);
    } else if (prev && prev.words.length <= 2) {
      prev.words.push(...c.words);
      chunks.splice(i, 1);
      i--;
    } else if (next) {
      next.words.unshift(...c.words);
      chunks.splice(i, 1);
      i--;
    }
  }

  // hitung ulang rentang waktu tiap chunk setelah balancing
  for (const c of chunks) {
    c.start = c.words[0].start;
    c.end = c.words[c.words.length - 1].end;
  }

  return chunks;
}
