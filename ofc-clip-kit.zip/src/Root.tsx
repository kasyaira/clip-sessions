import React from 'react';
import {Composition, staticFile} from 'remotion';
import {loadFont} from '@remotion/fonts';
import {CANVAS, COMPOSITION_ID} from './config';
import {PropsSchema} from './schemas';
import {clipDurationInFrames, VerticalClip} from './vertical-clip/VerticalClip';
import demoWords from './data/demo-words.json';
import type {ClipData} from './types';

// Font lokal dari public/fonts — tidak butuh internet saat render.
loadFont({
  family: 'Poppins',
  url: staticFile('fonts/Poppins-ExtraBold.ttf'),
  weight: '800',
});
loadFont({
  family: 'Poppins',
  url: staticFile('fonts/Poppins-SemiBold.ttf'),
  weight: '600',
});
loadFont({
  family: 'Poppins',
  url: staticFile('fonts/Poppins-Medium.ttf'),
  weight: '500',
});

// Data demo (tanpa video) supaya `npm run studio` langsung menampilkan style preset.
const demo: ClipData = {
  id: 'demo',
  video: '',
  clipStart: 0,
  clipEnd: 15,
  words: demoWords as ClipData['words'],
};

export const RemotionRoot: React.FC = () => {
  return (
    <Composition
      id={COMPOSITION_ID}
      component={VerticalClip}
      durationInFrames={clipDurationInFrames(demo)}
      fps={CANVAS.fps}
      width={CANVAS.width}
      height={CANVAS.height}
      schema={PropsSchema}
      defaultProps={{data: demo}}
      calculateMetadata={({props}: {props: {data: ClipData}}) => ({
        durationInFrames: clipDurationInFrames(props.data),
      })}
    />
  );
};
