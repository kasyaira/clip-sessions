export type Word = {
  /** teks kata (tanda baca menempel, mis. "keren!") */
  text: string;
  /** detik, relatif dari awal klip */
  start: number;
  end: number;
};

export type Chunk = {
  words: Word[];
  start: number;
  end: number;
};

export type ClipData = {
  id: string;
  /** path video di dalam folder public/, mis. "input/raw.mp4". Kosongkan untuk mode demo. */
  video: string;
  /** detik: posisi potong awal di video sumber */
  clipStart: number;
  /** detik: posisi potong akhir di video sumber */
  clipEnd: number;
  words: Word[];
};

/** Sheet potongan yang diisi AI agent (render-inputs/clips.json) */
export type ClipSheet = {
  /** path video relatif terhadap folder public/ */
  video: string;
  clips: {
    id: string;
    /** detik di video sumber */
    start: number;
    /** detik di video sumber */
    end: number;
  }[];
};
