/**
 * ============================================================
 *  OFC CLIP KIT — STYLE CONFIG (SINGLE SOURCE OF TRUTH)
 * ============================================================
 *  SEMUA pengaturan tampilan ada di file ini.
 *  Jangan ubah komponen lain untuk mengubah gaya visual:
 *  ubah nilai di sini, dan SEMUA klip ikut berubah secara konsisten.
 * ============================================================
 */

import project from './project.json';

/** Dimensi kanvas & frame rate output */
export const CANVAS = {
  width: 1080,
  height: 1920,
  fps: 30,
} as const;

export const COMPOSITION_ID = project.compositionId;

/** Padding waktu (detik) di awal & akhir klip supaya napasnya natural */
export const TIMING = {
  lead: project.lead,
  tail: project.tail,
};

/** Video sumber diasumsikan landscape 16:9 (bahan podcast / talking head) */
export const VIDEO = {
  /** sudut membulat kartu video */
  radius: 26,
  boxShadow:
    '0 20px 55px rgba(35, 28, 15, 0.30), 0 4px 14px rgba(35, 28, 15, 0.18)',
  border: '1px solid rgba(22, 21, 19, 0.12)',
  /** volume audio video sumber, 0..1 */
  volume: 1,
  /** posisi vertikal TENGAH kartu video (fraksi tinggi kanvas).
   *  0.5 = persis tengah (default lama). 0.44 = kartu agak ke atas. */
  centerY: 0.44,
} as const;

/** Background blocking — tekstur kertas krem hangat */
export const PAPER = {
  /** warna fallback di belakang tekstur */
  color: '#F1EBDD',
  /** file tekstur di folder public/ (dibuat full-frame 1080x1920) */
  texture: 'textures/paper.png',
  /** kekuatan vignette gelap di pinggir kertas, 0..1 */
  vignette: 0.55,
} as const;

/** Lapisan grain halus di atas seluruh frame (biar video & kertas menyatu) */
export const GRAIN = {
  enabled: true,
  texture: 'textures/grain.png',
  opacity: 0.16,
  blend: 'overlay' as const,
  /** grain bergeser tiap frame -> film look hidup */
  animated: true,
};

/** Subtitle chunk 2-4 kata, clean minimal: putih + outline hitam */
export const SUBTITLE = {
  fontFamily: 'Poppins',
  fontWeight: '800',
  fontSize: 96,
  minFontSize: 64,
  color: '#FFFFFF',
  strokeColor: '#151310',
  strokeWidth: 13,
  lineHeight: 1.14,
  letterSpacing: '0.01em',
  shadow: 'drop-shadow(0 6px 16px rgba(0, 0, 0, 0.35))',
  /** lebar maksimum blok teks (fraksi dari lebar kanvas) */
  maxWidthRatio: 0.9,
  /** posisi vertikal tengah blok subtitle (fraksi tinggi kanvas). Kartu video dgn centerY 0.44 menempati y 0.28-0.60 */
  centerY: 0.595,
  /** animasi pop masuk */
  staggerFrames: 1.6,
  entryFrames: 13,
  spring: {damping: 13, stiffness: 230, mass: 0.55},
  /** animasi keluar cepat */
  exitFrames: 4,
  /** subtitle tetap tampil beberapa detik setelah chunk selesai (menghindari kelap-kelip saat jeda napas) */
  holdAfterEnd: 0.9,
  /** kata yang sedang diucap: berubah KUNING mengikuti irama bicara per kata,
   *  sedikit membesar, penuh opasitas; kata lain tetap putih & terbaca jelas */
  activeWord: {
    enabled: true,
    scale: 1.08,
    /** opasitas kata non-aktif — tetap tinggi agar warna tetap keliatan */
    dimOpacity: 0.85,
    /** warna highlight kata yang sedang diucap (kuning terang) */
    color: '#FFD60A',
    /** durasi ramp kuning saat kata mulai diucap (frame) */
    onFrames: 2,
    /** durasi fade balik ke putih setelah kata selesai (frame) */
    fadeFrames: 3,
    /** tahan kuning sesaat setelah kata selesai supaya tidak kedip (detik) */
    holdBuffer: 0.3,
  },
  /** aturan pemecah chunk: ideal & maksimal jumlah kata per popup */
  chunk: {preferWords: 3, maxWords: 4},
} as const;

export const WATERMARK = {
  text: '@ofkiehme',
  fontFamily: 'Poppins',
  fontWeight: '600',
  fontSize: 30,
  letterSpacing: '0.14em',
  color: 'rgba(24, 21, 16, 0.55)',
  /** jarak dari tepi atas frame (px) */
  top: 92,
} as const;

export const PROGRESS_BAR = {
  height: 7,
  color: '#181510',
  track: 'rgba(24, 21, 16, 0.10)',
} as const;
