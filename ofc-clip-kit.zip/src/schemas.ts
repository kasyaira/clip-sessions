import {z} from 'zod';

export const ClipDataSchema = z.object({
  id: z.string().min(1),
  video: z.string(),
  clipStart: z.number().min(0),
  clipEnd: z.number().positive(),
  words: z.array(
    z.object({
      text: z.string(),
      start: z.number().min(0),
      end: z.number().min(0),
    })
  ),
});

export const PropsSchema = z.object({
  data: ClipDataSchema,
});

export type Props = z.infer<typeof PropsSchema>;
