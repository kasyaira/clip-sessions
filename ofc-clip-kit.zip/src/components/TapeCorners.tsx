import React from 'react';
import {Easing, interpolate, useCurrentFrame} from 'remotion';
import {TAPE} from '../config';

/**
 * Strip "washi tape" menempel di tepi atas kartu video — dua strip
 * translucent yang menyilang tepi kartu (setengah di kertas, setengah
 * di video), memperkuat identitas "foto ditempel di kertas" preset.
 * Dirender DI LUAR kartu (yang overflow-hidden) supaya bagian strip
 * yang menjorok keluar tepi kartu tetap kelihatan.
 *
 * Props memakai ukuran kartu (width/height) — posisi strip relatif
 * terhadap wrapper kartu di VerticalClip.
 */
export const TapeCorners: React.FC = () => {
  const frame = useCurrentFrame();
  if (!TAPE.enabled) {
    return null;
  }

  const p = interpolate(frame, [6, 24], [0, 1], {
    easing: Easing.out(Easing.cubic),
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });

  const strip: React.CSSProperties = {
    position: 'absolute',
    width: TAPE.width,
    height: TAPE.height,
    background: TAPE.bg,
    border: TAPE.border,
    boxShadow: TAPE.shadow,
    borderRadius: 3,
    top: -Math.round(TAPE.height / 2) + 4,
    opacity: p,
  };

  return (
    <>
      <div
        style={{
          ...strip,
          left: TAPE.inset,
          transform: `rotate(-${TAPE.rotate}deg) translateY(${(1 - p) * -14}px)`,
        }}
      />
      <div
        style={{
          ...strip,
          right: TAPE.inset,
          transform: `rotate(${TAPE.rotate}deg) translateY(${(1 - p) * -14}px)`,
        }}
      />
    </>
  );
};
