import React from 'react';
import {WATERMARK} from '../config';

/** Watermark @ofkiehme — posisi atas-tengah di area kertas */
export const Watermark: React.FC = () => {
  return (
    <div
      style={{
        position: 'absolute',
        top: WATERMARK.top,
        left: 0,
        width: '100%',
        textAlign: 'center',
        fontFamily: WATERMARK.fontFamily,
        fontWeight: WATERMARK.fontWeight,
        fontSize: WATERMARK.fontSize,
        letterSpacing: WATERMARK.letterSpacing,
        color: WATERMARK.color,
        userSelect: 'none',
      }}
    >
      {WATERMARK.text}
    </div>
  );
};
