import React, {useMemo} from 'react';
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {CANVAS, SUBTITLE} from '../config';
import type {Chunk} from '../types';

const clamp = (v: number, min: number, max: number) =>
  Math.min(max, Math.max(min, v));

/** campur dua warna hex, p = 0 (a) .. 1 (b) */
const blendHex = (a: string, b: string, p: number): string => {
  const pa = parseInt(a.slice(1), 16);
  const pb = parseInt(b.slice(1), 16);
  const ch = (shift: number) => {
    const ca = (pa >> shift) & 255;
    const cb = (pb >> shift) & 255;
    return Math.round(ca + (cb - ca) * p);
  };
  return `rgb(${ch(16)}, ${ch(8)}, ${ch(0)})`;
};

/**
 * Subtitle popup mengikuti irama bicara (gaya karaoke):
 *  - chunk 2-4 kata muncul serentak dengan pop/bounce per kata (stagger tipis)
 *  - KATA YANG DIUCAPKAN berubah KUNING + membesar; kata yang sudah lewat
 *    tetap kuning (progressive); kata berikutnya meredup — mengikuti irama
 *    bicara per kata (timing word-level dari whisper)
 *  - keluar cepat sebelum chunk berikutnya muncul
 *  - saat jeda napas, chunk terakhir tetap tergantung sebentar (holdAfterEnd)
 */
export const Subtitles: React.FC<{chunks: Chunk[]}> = ({chunks}) => {
  const frame = useCurrentFrame();
  const {fps, height} = useVideoConfig();
  const t = frame / fps;

  // chunk aktif = chunk terakhir yang waktunya sudah mulai
  const activeIdx = useMemo(() => {
    let idx = -1;
    for (let i = 0; i < chunks.length; i++) {
      if (chunks[i].start <= t) {
        idx = i;
      } else {
        break;
      }
    }
    return idx;
  }, [chunks, t]);

  if (activeIdx === -1) {
    return null;
  }

  const chunk = chunks[activeIdx];
  const next = chunks[activeIdx + 1];
  const visibleUntil = next
    ? Math.min(next.start, chunk.end + SUBTITLE.holdAfterEnd)
    : chunk.end + SUBTITLE.holdAfterEnd;
  if (t >= visibleUntil) {
    return null;
  }

  const chunkStartFrame = Math.round(chunk.start * fps);
  const exitStartFrame = Math.round(visibleUntil * fps) - SUBTITLE.exitFrames;
  const exitP = clamp((frame - exitStartFrame) / SUBTITLE.exitFrames, 0, 1);

  // kata yang sedang diucap di dalam chunk (kata terakhir yang sudah mulai)
  let wordIdx = 0;
  for (let i = 0; i < chunk.words.length; i++) {
    if (chunk.words[i].start <= t) {
      wordIdx = i;
    }
  }

  // heuristic ukuran font: chunk panjang menyusut otomatis biar tetap muat
  const text = chunk.words.map((w) => w.text).join(' ');
  const estWidth = text.length * SUBTITLE.fontSize * 0.56;
  const maxW = CANVAS.width * SUBTITLE.maxWidthRatio;
  const fontSize = Math.max(
    SUBTITLE.minFontSize,
    Math.min(
      SUBTITLE.fontSize,
      (SUBTITLE.fontSize * maxW) / Math.max(estWidth, 1)
    )
  );

  const wordStyle = (i: number): React.CSSProperties => {
    const delay = i * SUBTITLE.staggerFrames;
    const s = spring({
      fps,
      frame: Math.max(0, frame - chunkStartFrame - delay),
      config: SUBTITLE.spring,
      durationInFrames: SUBTITLE.entryFrames,
    });

    const w = chunk.words[i];
    const isActive = SUBTITLE.activeWord.enabled && i === wordIdx;
    const spoken = SUBTITLE.activeWord.enabled && i <= wordIdx;
    // progres transisi warna kata ini: 0 -> 1 sesaat setelah kata diucapkan
    const actP = SUBTITLE.activeWord.enabled
      ? clamp((t - w.start) / SUBTITLE.activeWord.fadeIn, 0, 1)
      : 0;

    // kata diucapkan -> blend putih ke kuning; kata berikutnya -> putih meredup
    const color = spoken
      ? blendHex(SUBTITLE.color, SUBTITLE.activeWord.color, actP)
      : SUBTITLE.color;
    const op = spoken ? 1 : SUBTITLE.activeWord.dimOpacity;
    // pop hanya pada kata yang SEDANG diucapkan (ramp halus masuk)
    const pop = isActive
      ? 1 + (SUBTITLE.activeWord.scale - 1) * actP
      : 1;

    return {
      display: 'inline-block',
      fontFamily: SUBTITLE.fontFamily,
      fontWeight: SUBTITLE.fontWeight,
      fontSize,
      lineHeight: SUBTITLE.lineHeight,
      letterSpacing: SUBTITLE.letterSpacing,
      color,
      WebkitTextStroke: `${SUBTITLE.strokeWidth}px ${SUBTITLE.strokeColor}`,
      paintOrder: 'stroke',
      whiteSpace: 'pre',
      margin: `0 ${Math.round(fontSize * 0.09)}px`,
      transform: `translateY(${(1 - s) * 30}px) scale(${s * pop})`,
      opacity: s * op,
      filter: SUBTITLE.shadow,
    };
  };

  return (
    <AbsoluteFill>
      <div
        style={{
          position: 'absolute',
          left: (CANVAS.width * (1 - SUBTITLE.maxWidthRatio)) / 2,
          width: CANVAS.width * SUBTITLE.maxWidthRatio,
          top: SUBTITLE.centerY * height,
          transform: `translateY(-50%) scale(${1 - exitP * 0.04})`,
          opacity: 1 - exitP,
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          alignContent: 'center',
        }}
      >
        {chunk.words.map((w, i) => (
          <span key={`${activeIdx}-${i}`} style={wordStyle(i)}>
            {w.text}
          </span>
        ))}
      </div>
    </AbsoluteFill>
  );
};
