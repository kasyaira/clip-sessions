import React, {useMemo} from 'react';
import {AbsoluteFill, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {CANVAS, SUBTITLE} from '../config';
import type {Chunk} from '../types';

const clamp = (v: number, min: number, max: number) =>
  Math.min(max, Math.max(min, v));

/** ---- util warna: lerp hex deterministik per frame (tanpa CSS transition) ---- */
const hexToRgb = (hex: string): [number, number, number] => {
  const h = hex.replace('#', '');
  const full =
    h.length === 3
      ? h
          .split('')
          .map((c) => c + c)
          .join('')
      : h;
  return [
    parseInt(full.slice(0, 2), 16),
    parseInt(full.slice(2, 4), 16),
    parseInt(full.slice(4, 6), 16),
  ];
};

const lerpHex = (from: string, to: string, k: number): string => {
  const a = hexToRgb(from);
  const b = hexToRgb(to);
  const m = clamp(k, 0, 1);
  const c = a.map((v, i) => Math.round(v + (b[i] - v) * m));
  return `rgb(${c[0]}, ${c[1]}, ${c[2]})`;
};

/**
 * Subtitle popup mengikuti irama bicara:
 *  - chunk 2-4 kata muncul serentak dengan pop/bounce per kata (stagger tipis)
 *  - KARAOKE: begitu sebuah kata diucap ia MENYALA KUNING (lerp cepat dari
 *    putih) + kata aktif membesar sedikit; kata yang sudah diucap tetap
 *    kuning sampai chunk keluar, kata berikutnya masih putih
 *  - keluar cepat sebelum chunk berikutnya muncul
 *  - saat jeda napas, chunk terakhir tetap tergantung sebentar (holdAfterEnd)
 */
export const Subtitles: React.FC<{chunks: Chunk[]}> = ({chunks}) => {
  const frame = useCurrentFrame();
  const {fps, height} = useVideoConfig();
  const t = frame / fps;

  // chunk aktif = chunk terakhir yang waktunya sudah mulai
  const activeIdx = useMemo(() => {
    let idx = -1;
    for (let i = 0; i < chunks.length; i++) {
      if (chunks[i].start <= t) {
        idx = i;
      } else {
        break;
      }
    }
    return idx;
  }, [chunks, t]);

  if (activeIdx === -1) {
    return null;
  }

  const chunk = chunks[activeIdx];
  const next = chunks[activeIdx + 1];
  const visibleUntil = next
    ? Math.min(next.start, chunk.end + SUBTITLE.holdAfterEnd)
    : chunk.end + SUBTITLE.holdAfterEnd;
  if (t >= visibleUntil) {
    return null;
  }

  const chunkStartFrame = Math.round(chunk.start * fps);
  const exitStartFrame = Math.round(visibleUntil * fps) - SUBTITLE.exitFrames;
  const exitP = clamp((frame - exitStartFrame) / SUBTITLE.exitFrames, 0, 1);

  // kata yang sedang diucap di dalam chunk
  let wordIdx = 0;
  for (let i = 0; i < chunk.words.length; i++) {
    if (chunk.words[i].start <= t) {
      wordIdx = i;
    }
  }

  // heuristic ukuran font: chunk panjang menyusut otomatis biar tetap muat
  const text = chunk.words.map((w) => w.text).join(' ');
  const estWidth = text.length * SUBTITLE.fontSize * 0.56;
  const maxW = CANVAS.width * SUBTITLE.maxWidthRatio;
  const fontSize = Math.max(
    SUBTITLE.minFontSize,
    Math.min(
      SUBTITLE.fontSize,
      (SUBTITLE.fontSize * maxW) / Math.max(estWidth, 1)
    )
  );

  // durasi transisi putih -> kuning dalam detik
  const litSec = Math.max(SUBTITLE.activeWord.litFrames, 1) / fps;
  const baseColor = SUBTITLE.color;
  const hiColor = SUBTITLE.activeWord.color;
  const stayLit = SUBTITLE.spokenWord.enabled;

  const wordStyle = (i: number): React.CSSProperties => {
    const delay = i * SUBTITLE.staggerFrames;
    const s = spring({
      fps,
      frame: Math.max(0, frame - chunkStartFrame - delay),
      config: SUBTITLE.spring,
      durationInFrames: SUBTITLE.entryFrames,
    });
    const isActive = SUBTITLE.activeWord.enabled && i === wordIdx;

    // ---- warna karaoke per kata, deterministik dari timestamp whisper ----
    // lit: 0 = putih (belum diucap) -> 1 = kuning penuh (sedang/sudah diucap)
    let lit = 0;
    const w = chunk.words[i];
    if (w.start <= t) {
      lit = clamp((t - w.start) / litSec, 0, 1);
      if (!stayLit && w.end < t) {
        // mode non-karaoke: redup kembali setelah kata selesai diucap
        lit = clamp(1 - (t - w.end) / (litSec * 1.4), 0, 1);
      }
    }
    const color =
      SUBTITLE.activeWord.enabled && lit > 0
        ? lerpHex(baseColor, hiColor, lit)
        : baseColor;

    const pop = isActive ? SUBTITLE.activeWord.scale : 1;
    const op =
      SUBTITLE.activeWord.enabled && !isActive && lit === 0
        ? SUBTITLE.activeWord.dimOpacity
        : 1;
    const filter = isActive
      ? `${SUBTITLE.shadow} ${SUBTITLE.activeWord.glow}`
      : SUBTITLE.shadow;

    return {
      display: 'inline-block',
      fontFamily: SUBTITLE.fontFamily,
      fontWeight: SUBTITLE.fontWeight,
      fontSize,
      lineHeight: SUBTITLE.lineHeight,
      letterSpacing: SUBTITLE.letterSpacing,
      color,
      WebkitTextStroke: `${SUBTITLE.strokeWidth}px ${SUBTITLE.strokeColor}`,
      paintOrder: 'stroke',
      whiteSpace: 'pre',
      margin: `0 ${Math.round(fontSize * 0.09)}px`,
      transform: `translateY(${(1 - s) * 30}px) scale(${s * pop})`,
      opacity: s * op,
      filter,
    };
  };

  return (
    <AbsoluteFill>
      <div
        style={{
          position: 'absolute',
          left: (CANVAS.width * (1 - SUBTITLE.maxWidthRatio)) / 2,
          width: CANVAS.width * SUBTITLE.maxWidthRatio,
          top: SUBTITLE.centerY * height,
          transform: `translateY(-50%) scale(${1 - exitP * 0.04})`,
          opacity: 1 - exitP,
          display: 'flex',
          flexWrap: 'wrap',
          justifyContent: 'center',
          alignContent: 'center',
        }}
      >
        {chunk.words.map((w, i) => (
          <span key={`${activeIdx}-${i}`} style={wordStyle(i)}>
            {w.text}
          </span>
        ))}
      </div>
    </AbsoluteFill>
  );
};
