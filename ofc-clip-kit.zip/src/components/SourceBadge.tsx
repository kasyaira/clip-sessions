import React from 'react';
import {Easing, interpolate, useCurrentFrame} from 'remotion';
import {SOURCE} from '../config';

/** Ikon play: kotak membulat + segitiga murni CSS (tanpa glyph font
 *  -> dijamin selalu render di Chrome headless, tidak ada risiko tofu) */
const PlayIcon: React.FC = () => {
  const size = SOURCE.iconSize;
  return (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: SOURCE.iconRadius,
        background: SOURCE.iconBg,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexShrink: 0,
      }}
    >
      <div
        style={{
          width: 0,
          height: 0,
          borderTop: `${Math.round(size * 0.22)}px solid transparent`,
          borderBottom: `${Math.round(size * 0.22)}px solid transparent`,
          borderLeft: `${Math.round(size * 0.33)}px solid rgba(255, 255, 255, 0.96)`,
          marginLeft: Math.round(size * 0.05),
        }}
      />
    </div>
  );
};

/**
 * Badge "source: <nama channel>" — pojok kiri bawah, di atas progress bar.
 * Nama channel datang dari data klip (field sourceChannel, diisi dari
 * render-inputs/clips.json oleh build-data); fallback ke SOURCE.text.
 * Chip frosted-paper + ikon play: kecil, tenang, tapi selalu terbaca.
 */
export const SourceBadge: React.FC<{channel?: string}> = ({channel}) => {
  const frame = useCurrentFrame();
  const name = (channel ?? '').trim() || SOURCE.text.trim();
  if (!SOURCE.enabled || !name) {
    return null;
  }

  const p = interpolate(
    frame,
    [SOURCE.fadeDelayFrames, SOURCE.fadeDelayFrames + SOURCE.fadeInFrames],
    [0, 1],
    {
      easing: Easing.out(Easing.cubic),
      extrapolateLeft: 'clamp',
      extrapolateRight: 'clamp',
    }
  );

  return (
    <div
      style={{
        position: 'absolute',
        left: SOURCE.left,
        bottom: SOURCE.bottom,
        opacity: p,
        transform: `translateY(${(1 - p) * SOURCE.risePx}px)`,
        pointerEvents: 'none',
        zIndex: 30,
      }}
    >
      <div
        style={{
          display: 'flex',
          alignItems: 'center',
          gap: SOURCE.gap,
          height: SOURCE.height,
          padding: `0 ${SOURCE.paddingH}px`,
          borderRadius: SOURCE.radius,
          background: SOURCE.bg,
          border: SOURCE.border,
          boxShadow: SOURCE.shadow,
          fontFamily: SOURCE.fontFamily,
          whiteSpace: 'nowrap',
        }}
      >
        <PlayIcon />
        <span
          style={{
            fontSize: SOURCE.labelSize,
            fontWeight: SOURCE.labelWeight,
            color: SOURCE.labelColor,
            letterSpacing: SOURCE.letterSpacing,
          }}
        >
          {SOURCE.label}:
        </span>
        <span
          style={{
            fontSize: SOURCE.channelSize,
            fontWeight: SOURCE.channelWeight,
            color: SOURCE.channelColor,
            letterSpacing: SOURCE.letterSpacing,
          }}
        >
          {name}
        </span>
      </div>
    </div>
  );
};
