import React from 'react';
import {AbsoluteFill, Img, staticFile, useCurrentFrame, random} from 'remotion';
import {GRAIN, PAPER} from '../config';

/**
 * Background blocking: tekstur kertas krem full-frame + vignette halus.
 * Membuat frame vertikal terasa "sengaja didesain", bukan video landscape yang dipaksa.
 */
export const PaperBackground: React.FC = () => {
  return (
    <AbsoluteFill>
      <Img
        src={staticFile(PAPER.texture)}
        style={{
          position: 'absolute',
          inset: 0,
          width: '100%',
          height: '100%',
          objectFit: 'cover',
        }}
      />
      <AbsoluteFill
        style={{
          background:
            'radial-gradient(120% 120% at 50% 50%, rgba(28,22,10,0) 52%, rgba(28,22,10,0.16) 100%)',
          opacity: PAPER.vignette,
        }}
      />
    </AbsoluteFill>
  );
};

/**
 * Grain halus di atas video + kertas supaya keduanya menyatu (film look).
 * Posisi grain di-seed per frame -> deterministik & terasa hidup.
 */
export const GrainOverlay: React.FC = () => {
  const frame = useCurrentFrame();

  if (!GRAIN.enabled) {
    return null;
  }

  const style: React.CSSProperties = {
    position: 'absolute',
    inset: 0,
    backgroundImage: `url(${staticFile(GRAIN.texture)})`,
    backgroundRepeat: 'repeat',
    opacity: GRAIN.opacity,
    mixBlendMode: GRAIN.blend,
    pointerEvents: 'none',
  };

  if (GRAIN.animated) {
    const x = Math.floor(random(`grain-x-${frame}`) * 512);
    const y = Math.floor(random(`grain-y-${frame}`) * 512);
    style.backgroundPosition = `${x}px ${y}px`;
  }

  return <div style={style} />;
};
