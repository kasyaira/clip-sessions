import React from 'react';
import {PROGRESS_BAR} from '../config';

/** Garis tipis progres video di tepi atas layar */
export const ProgressBar: React.FC<{progress: number}> = ({progress}) => {
  const p = Math.min(1, Math.max(0, progress));
  return (
    <div
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        right: 0,
        height: PROGRESS_BAR.height,
        background: PROGRESS_BAR.track,
      }}
    >
      <div
        style={{
          height: '100%',
          width: `${p * 100}%`,
          background: PROGRESS_BAR.color,
        }}
      />
    </div>
  );
};
